@extends('backend.layout.app')
@section('title', 'Wash Report Dashboard | ' . Helper::getSettings('application_name') ?? 'Tusuka')
@section('content')
    <div class="container-fluid px-4">
        <h4 class="mt-2">Wash Report Dashboard</h4>

        <!-- Filter Card -->
        <div class="card my-3">
            <div class="card-body">
                <form method="GET" id="filter_form">
                    <div class="row">
                        <div class="col-md-4 mb-2">
                            <label for="from_date" class="form-label">From Date</label>
                            <input type="date" class="form-control" name="from_date" id="from_date">
                        </div>
                        <div class="col-md-4 mb-2">
                            <label for="to_date" class="form-label">To Date</label>
                            <input type="date" class="form-control" name="to_date" id="to_date">
                        </div>
                        <div class="col-md-4 mb-2 d-flex align-items-end">
                            <div class="form-group w-100">
                                <button type="submit" id="filterBtn" class="btn btn-primary">
                                    <i class="feather icon-filter"></i> Apply Filter
                                </button>
                                <button type="button" id="resetBtn" class="btn btn-secondary">
                                    <i class="feather icon-refresh-cw"></i> Reset
                                </button>
                                <button type="button" id="todayBtn" class="btn btn-info">
                                    <i class="feather icon-calendar"></i> Today
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Date Info Card -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0">Showing Data For Date Range</h6>
                                <h4 class="mb-0" id="dateRange">Loading...</h4>
                            </div>
                            <i class="fa-solid fa-calendar fa-3x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Summary Cards -->
        {{-- <div class="row mb-4">
            <div class="col-xl-2 col-md-4">
                <div class="card bg-primary text-white mb-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0">Total Units</h6>
                                <h3 class="mb-0" id="totalUnits">0</h3>
                            </div>
                            <i class="fa-solid fa-building fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4">
                <div class="card bg-success text-white mb-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0">Total Machines</h6>
                                <h3 class="mb-0" id="totalMachines">0</h3>
                            </div>
                            <i class="fa-solid fa-gear fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4">
                <div class="card bg-warning text-white mb-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0">Total Capacity</h6>
                                <h3 class="mb-0" id="totalCapacity">0 kg</h3>
                            </div>
                            <i class="fa-solid fa-weight-scale fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4">
                <div class="card bg-danger text-white mb-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0">Total Manpower</h6>
                                <h3 class="mb-0" id="totalManpower">0</h3>
                            </div>
                            <i class="fa-solid fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4">
                <div class="card bg-info text-white mb-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0">Total Received</h6>
                                <h3 class="mb-0" id="totalReceived">0</h3>
                            </div>
                            <i class="fa-solid fa-boxes-packing fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-2 col-md-4">
                <div class="card bg-secondary text-white mb-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0">Total Delivery</h6>
                                <h3 class="mb-0" id="totalDelivery">0</h3>
                            </div>
                            <i class="fa-solid fa-truck fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div> --}}

        <!-- Unit Data Table Card -->
        <div class="card mb-4">
            <div class="card-header bg-secondary text-white">
                <div class="row">
                    <div class="col-12 d-flex justify-content-between">
                        <div class="d-flex align-items-center">
                            <h5 class="m-0">Unit Details with Latest Manpower & Production Data</h5>
                        </div>
                        <div>
                            <button type="button" class="btn btn-dark" id="downloadPdfBtn">
                                <i class="fa-solid fa-file-pdf"></i> Download PDF Report
                            </button>
                            <button type="button" class="btn btn-success" id="refreshBtn">
                                <i class="fa-solid fa-rotate"></i> Refresh
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-bordered text-center" id="unitDataTable">
                    <thead>
                        <tr>
                            <th>Unit</th>
                            <th>Used MC</th> <!-- Changed from "Machines" -->
                            <th>Used Capacity (kg)</th> <!-- Changed from "Capacity (kg)" -->
                            <th>Sewing Lines</th>
                            <th>Direct</th>
                            <th>Indirect</th>
                            <th>Total</th>
                            <th>Work Hours</th>
                            {{-- <th>SMV</th> --}}
                            <th>Received</th>
                            <th>Delivery</th>
                            <th>Garment (g)</th>
                            <th>Forecast Target</th>
                            <th>Deviation</th>
                            <th>Deviation %</th>
                            <th>Rewash %</th>
                            <th>In Hand Balance</th>
                            <th>First Wash</th>
                            <th>Final Wash</th>
                            <th>Wash WIP %</th>
                            <th>Acid Wash</th>
                            <th>Re-Wash</th>
                            <th>Rework Dry Proc</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody class="text-center"></tbody>

                    <tfoot class="bg-light font-weight-bold">
                        <tr>
                            <th class="text-center">Totals:</th>
                            <th class="text-center" id="footerMachines">0</th>
                            <th class="text-center" id="footerCapacity">0 kg</th>
                            <th class="text-center" id="footerSewingLines">-</th>
                            <th class="text-center" id="footerDirect">0</th>
                            <th class="text-center" id="footerIndirect">0</th>
                            <th class="text-center" id="footerTotal">0</th>
                            <th class="text-center" id="footerWorkHours">0.00</th>
                            {{-- <th class="text-center" id="footerSMV">0.00</th> --}}
                            <th class="text-center" id="footerDelivery">0</th>
                            <th class="text-center" id="footerReceived">0</th>

                            <th class="text-center" id="footerGarment">-</th>
                            <th class="text-center" id="footerForecastTarget">0</th>
                            <th class="text-center" id="footerDeviation">0</th>
                            <th class="text-center" id="footerDeviationPercent">0%</th>
                            <!-- NEW FOOTER -->
                            <th class="text-center" id="footerRewashPercent">0%</th> <!-- NEW FOOTER -->
                            <th class="text-center" id="footerInHandBalance">586,066</th> <!-- NEW FOOTER -->
                            <th class="text-center" id="footerFirstWash">0</th>
                            <th class="text-center" id="footerFinalWash">0</th>
                            <th class="text-center" id="footerWashRatio">0</th>
                            <th class="text-center" id="footerAcidWash">0</th>
                            <th class="text-center" id="footerReWash">0</th>
                            <th class="text-center" id="footerReworkDryProc">0</th>
                            <th class="text-center" id="footerRemarks">-</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <!-- Two New Tables Section -->
        <div class="row">
            <!-- First Dry Process Table -->
            <div class="col-lg-6">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="m-0">1st Dry Process - Latest Data</h5>
                    </div>
                    <div class="card-body table-responsive">
                        <table class="table table-bordered text-center" id="firstDryProcessTable">
                            <thead>
                                <tr>
                                    <th rowspan="2">Plant</th>
                                    <th colspan="2">Whisker</th>
                                    <th colspan="2">Hand Brush</th>
                                    <th colspan="2">1st Dry Final</th>
                                    <th rowspan="2">Deviation</th>
                                    <th rowspan="2">Defect Qty</th>
                                    <th rowspan="2">Used Manpower</th>
                                    <th rowspan="2">Working Hours</th>
                                    <th rowspan="2">SMV</th>
                                </tr>
                                <tr>
                                    <th>Target</th>
                                    <th>Prod.</th>
                                    <th>Target</th>
                                    <th>Prod.</th>
                                    <th>Target</th>
                                    <th>Prod.</th>
                                </tr>
                            </thead>
                            <tbody class="text-center"></tbody>
                            <tfoot class="bg-light font-weight-bold">
                                <tr>
                                    <th class="text-center">Totals/Avg:</th>
                                    <th class="text-center" id="footerWhiskerTarget">0</th>
                                    <th class="text-center" id="footerWhiskerProd">0</th>
                                    <th class="text-center" id="footerHandbrushTarget">0</th>
                                    <th class="text-center" id="footerHandbrushProd">0</th>
                                    <th class="text-center" id="footerFirstDryTarget">0</th>
                                    <th class="text-center" id="footerFirstDryProd">0</th>
                                    <th class="text-center">0</th>
                                    <th class="text-center">0</th>
                                    <th class="text-center" id="footerFirstManpower">0</th>
                                    <th class="text-center" id="footerFirstWorkingHr">0.00</th>
                                    <th class="text-center" id="footerFirstSmv">0.00</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Second Dry Process Table -->
            <div class="col-lg-6">
                <div class="card mb-4">
                    <div class="card-header bg-success text-white">
                        <h5 class="m-0">2nd Dry Process - Latest Data</h5>
                    </div>
                    <div class="card-body table-responsive">
                        <table class="table table-bordered text-center" id="secondDryProcessTable">
                            <thead>
                                <tr>
                                    <th rowspan="2">Plant</th>
                                    <th colspan="2">Laser</th>
                                    <th colspan="2">PP Spray</th>
                                    <th colspan="2">2nd Dry Final</th>
                                    <th rowspan="2">Deviation</th>
                                    <th rowspan="2">Defect Qty</th>
                                    <th rowspan="2">Used Manpower</th>
                                    <th rowspan="2">Working Hour</th>
                                    <th rowspan="2">SMV</th>
                                </tr>
                                <tr>
                                    <th>Target</th>
                                    <th>Prod.</th>
                                    <th>Target</th>
                                    <th>Prod.</th>
                                    <th>Target</th>
                                    <th>Prod.</th>
                                </tr>
                            </thead>
                            <tbody class="text-center"></tbody>
                            <tfoot class="bg-light font-weight-bold">
                                <tr>
                                    <th class="text-center">Total/Avg:</th>
                                    <th class="text-center" id="footerLaserTarget">0</th>
                                    <th class="text-center" id="footerLaserProd">0</th>
                                    <th class="text-center" id="footerPpTarget">0</th>
                                    <th class="text-center" id="footerPpProd">0</th>
                                    <th class="text-center" id="footerSecondDryTarget">0</th>
                                    <th class="text-center" id="footerSecondDryProd">0</th>
                                    <th class="text-center">0</th>
                                    <th class="text-center">0</th>
                                    <th class="text-center" id="footerSecondManpower">0</th>
                                    <th class="text-center" id="footerSecondWorkingHr">0.00</th>
                                    <th class="text-center" id="footerSecondSmv">0.00</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Dryer Data and Transfer Tables Section - Two Columns -->
            <div class="row mt-4">
                <!-- Transfer Data Table -->
                <div class="col-lg-6">
                    <div class="card mb-4">
                        <div class="card-header bg-info text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="m-0">Transfer Data - Latest</h5>
                                <div>
                                    <span class="badge bg-light text-dark me-1" id="totalTransfersBadge">0</span>
                                    <span class="badge bg-success" id="verifiedTransfersBadge">0</span>
                                    <span class="badge bg-warning text-dark" id="pendingTransfersBadge">0</span>
                                    <span class="badge bg-danger" id="rejectedTransfersBadge">0</span>
                                </div>
                            </div>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-bordered text-center" id="transferDataTable" style="width:100%">
                                <thead>
                                    <tr>
                                        <th rowspan="2">Unit</th>
                                        <th colspan="2">Machine</th>
                                        <th rowspan="2">Transfer In</th>
                                        <th rowspan="2">Transfer Out</th>
                                        <th colspan="2">Target</th>
                                        <th colspan="2">M Capacity(pcs)</th>
                                        <th colspan="2">M Capacity(kg)</th>
                                    </tr>
                                    <tr>
                                        <th>Exist M</th>
                                        <th>Used M</th>
                                        <th>Exist M</th>
                                        <th>Used M</th>
                                        <th>Exist M</th>
                                        <th>Used M</th>
                                        <th>Exist M</th>
                                        <th>Used M</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center"></tbody>
                                <tfoot class="bg-light font-weight-bold">
                                    <tr>
                                        <th>Totals/Avg:</th>
                                        <th id="footerExistingMc">0</th>
                                        <th id="footerUsedMc">0</th>
                                        <th id="footerTransferIn">-</th>
                                        <th id="footerTransferOut">-</th>
                                        <th id="footerBaseMg">0</th>
                                        <th id="footerCurrentMg">0</th>
                                        <th id="footerBasePcs">0</th>
                                        <th id="footerCurrentPcs">0</th>
                                        <th id="footerBaseKg">0</th>
                                        <th id="footerCurrentKg">0</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Dryer Data Table -->
                <div class="col-lg-6">
                    <div class="card mb-4">
                        <div class="card-header bg-warning text-dark">
                            <h5 class="m-0">Dryer Data - Latest Data</h5>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-bordered text-center" id="dryerDataTable">
                                <thead>
                                    <tr>
                                        <th>Unit</th>
                                        <th># Dryer</th>
                                        <th>Avg Batch</th>
                                        <th>Avg Time</th>
                                        <th>Capacity</th>
                                        {{-- <th>Target</th> --}}
                                        <th>1st Wash</th>
                                        <th>Cold</th>
                                        <th>Meas Corr</th>
                                        <th>Final Wash</th>
                                        <th>Deviation</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center"></tbody>
                                <tfoot class="bg-light font-weight-bold">
                                    <tr>
                                        <th>Totals:</th>
                                        <th class="text-center" id="footerNumDryer">0</th>
                                        <th id="footerAvgBatch">0.0</th>
                                        <th class="text-center" id="footerAvgDryerTime">0.0</th>
                                        <th id="footerCapacity">-</th>
                                        {{-- <th id="footerTargetQty">0.0</th> --}}
                                        <th id="footerFirstWashDryer">0.0</th>
                                        <th id="footerColdDryer">0.0</th>
                                        <th id="footerMeasCorrection">0.0</th>
                                        <th id="footerFinalWashDryer">0.0</th>
                                        <th id="footerDeviation">0.0</th>
                                        <th id="footerTotalDryer">0.0</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Machine Status Chart Card -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="m-0">Machine Performance</h5>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-10">
                                <div style="height: 500px;"> <!-- Increased from 400px to 500px -->
                                    <canvas id="cappChart"></canvas>
                                </div>
                            </div>
                            <div class="col-lg-2">
                                <div class="card bg-light h-50 justify-content-end mt-5">
                                    <div class="card-body">
                                        <h6 class="card-title">Period Information</h6>
                                        <p class="mb-2"><strong>From:</strong> <span id="cappFrom"
                                                class="small"></span></p>
                                        <p class="mb-2"><strong>To:</strong> <span id="cappTo"
                                                class="small"></span></p>
                                        <hr>
                                        <div class="mt-2">
                                            <p class="mb-1 small">
                                                <i class="fa-solid fa-circle text-danger me-1"></i>Downtime: <span
                                                    id="downtimeValueDetail">0</span>%
                                            </p>
                                            <p class="mb-1 small">
                                                <i class="fa-solid fa-circle text-warning me-1"></i>Idletime: <span
                                                    id="idletimeValueDetail">0</span>%
                                            </p>
                                            <p class="mb-1 small">
                                                <i class="fa-solid fa-circle text-success me-1"></i>Uptime: <span
                                                    id="uptimeValueDetail">0</span>%
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Remarks Modal -->
    <div class="modal fade" id="remarkModal" tabindex="-1" aria-labelledby="remarkModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="remarkModalLabel">
                        <i class="fa-solid fa-pen-to-square me-2"></i>
                        Add/Edit Remark
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="remarkForm">
                        <input type="hidden" id="remark_unit" name="unit">
                        <input type="hidden" id="remark_date" name="date">
                        <input type="hidden" id="remark_id" name="id">

                        <div class="mb-3">
                            <label for="unit_display" class="form-label fw-bold">Unit</label>
                            <input type="text" class="form-control bg-light" id="unit_display" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="date_display" class="form-label fw-bold">Date</label>
                            <input type="text" class="form-control bg-light" id="date_display" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="remark_text" class="form-label fw-bold">Remark</label>
                            <textarea class="form-control" id="remark_text" name="remark" rows="4"
                                placeholder="Enter your remark here..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fa-solid fa-times me-1"></i> Cancel
                    </button>
                    <button type="button" class="btn btn-primary" id="saveRemarkBtn">
                        <i class="fa-solid fa-save me-1"></i> Save Remark
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Remarks History Modal -->
    <div class="modal fade" id="remarksHistoryModal" tabindex="-1" aria-labelledby="remarksHistoryModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="remarksHistoryModalLabel">
                        <i class="fa-solid fa-clock-rotate-left me-2"></i>
                        Remarks History
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <h6 id="history_unit_name" class="fw-bold"></h6>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="remarksHistoryTable">
                            <thead class="table-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Remark</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="remarksHistoryBody">
                                <tr>
                                    <td colspan="3" class="text-center">Loading...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fa-solid fa-times me-1"></i> Close
                    </button>
                </div>
            </div>
        </div>
    </div>

    <style>
        .remark-text {
            cursor: pointer;
            transition: all 0.2s ease;
            border-bottom: 1px dashed #6c757d;
        }

        .remark-text:hover {
            background-color: #e9ecef;
            border-bottom: 1px solid #0d6efd;
        }

        .remark-toggle-btn {
            opacity: 0.6;
            transition: opacity 0.2s ease;
        }

        .remark-toggle-btn:hover {
            opacity: 1;
        }

        tr:hover .remark-toggle-btn {
            opacity: 1;
        }

        .modal-header {
            border-bottom: none;
        }

        .modal-footer {
            border-top: none;
        }

        #remark_text {
            resize: vertical;
        }

        table thead tr:first-child th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
        }

        table thead tr:nth-child(2) th {
            background-color: #e9ecef;
            font-size: 0.9em;
        }

        /* Transfer table styling */
        #transferDataTable thead tr:first-child th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            text-align: center;
            vertical-align: middle;
        }

        #transferDataTable thead tr:nth-child(2) th {
            background-color: #e9ecef;
            font-size: 0.85em;
            text-align: center;
            vertical-align: middle;
        }

        #transferDataTable tbody td {
            vertical-align: middle;
        }

        /* Style for transfer details */
        #transferDataTable td:nth-child(5),
        #transferDataTable td:nth-child(6) {
            font-size: 0.85em;
            text-align: left;
            white-space: nowrap;
        }

        /* Responsive adjustments */
        @media (max-width: 1400px) {
            #transferDataTable {
                font-size: 0.8em;
            }

            #transferDataTable td:nth-child(5),
            #transferDataTable td:nth-child(6) {
                font-size: 0.75em;
            }
        }

        /* Simple Transfer Table Styling */
        #transferDataTable thead tr:first-child th {
            background-color: #f0f0f0;
            font-weight: 600;
            text-align: center;
            vertical-align: middle;
        }

        #transferDataTable thead tr:nth-child(2) th {
            background-color: #f8f9fa;
            font-weight: 500;
            font-size: 0.9em;
        }

        #transferDataTable tbody td {
            vertical-align: middle;
            padding: 8px 5px;
        }

        /* Simple colors for transfer columns */
        .text-success {
            color: #28a745 !important;
            font-weight: 500;
        }

        .text-danger {
            color: #dc3545 !important;
            font-weight: 500;
        }

        .text-muted {
            color: #6c757d !important;
        }

        /* Footer styling */
        #transferDataTable tfoot th {
            background-color: #e9ecef;
            font-weight: 600;
            /* padding: 10px 5px; */
        }
    </style>
@endsection

@push('footer')
    <script type="text/javascript">
        $(document).ready(function() {
            // Set today's date as default
            var today = new Date().toISOString().split('T')[0];

            // Set both from and to dates to today by default
            $('#from_date').val(today);
            $('#to_date').val(today);

            // Update date range display
            updateDateRange();

            // Initialize Main DataTable
            var mainTable = $('#unitDataTable').DataTable({
                responsive: true,
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ route('admin.wash-report-dashboard.get-data') }}",
                    type: 'GET',
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                    },
                    dataSrc: function(json) {
                        // Update date range if available in response
                        if (json.date_range) {
                            $('#dateRange').text(json.date_range);
                        }
                        return json.data;
                    }
                },
                aLengthMenu: [
                    [10, 25, 50, 100, -1],
                    [10, 25, 50, 100, "All"]
                ],
                iDisplayLength: 10,
                order: [
                    [0, 'asc']
                ],
                columns: [{
                        data: 'unit',
                        name: 'unit'
                    }, // Column 0
                    {
                        data: 'used_mc', // CHANGED: from 'machines' to 'used_mc'
                        name: 'used_mc'
                    }, // Column 1 - Now showing Used MC
                    {
                        data: 'used_capacity_kg',
                        name: 'used_capacity_kg',
                        render: function(data, type, row) {
                            if (type === 'display') {
                                // Round and format with commas
                                return Math.round(data).toString().replace(/\B(?=(\d{3})+(?!\d))/g,
                                    ",");
                            }
                            return data; // Return raw data for sorting/filtering
                        }
                    },
                    {
                        data: 'sewing_lines',
                        name: 'sewing_lines'
                    }, // Column 3
                    {
                        data: 'direct',
                        name: 'direct'
                    }, // Column 4
                    {
                        data: 'indirect',
                        name: 'indirect'
                    }, // Column 5
                    {
                        data: 'total',
                        name: 'total'
                    }, // Column 6
                    {
                        data: 'work_hours',
                        name: 'work_hours'
                    }, // Column 7
                    // {
                    //     data: 'smv',
                    //     name: 'smv'
                    // }, 
                    {
                        data: 'delivery',
                        name: 'delivery'
                    }, // Column 10
                    {
                        data: 'received',
                        name: 'received'
                    }, // Column 9

                    {
                        data: 'garment',
                        name: 'garment'
                    }, // Column 11
                    {
                        data: 'forecast_target',
                        name: 'forecast_target'
                    }, // Column 12 (NEW)
                    {
                        data: 'deviation',
                        name: 'deviation'
                    }, // Column 13 (NEW)
                    {
                        data: 'deviation_percent',
                        name: 'deviation_percent'
                    }, // Column 14 (NEW)

                    {
                        data: 'rewash_percent',
                        name: 'rewash_percent'
                    }, // Column 16 (NEW)
                    {
                        data: 'in_hand_balance',
                        name: 'in_hand_balance'
                    }, // Column 17 (NEW)
                    {
                        data: 'first_wash_qty',
                        name: 'first_wash_qty'
                    }, // Column 13

                    {
                        data: 'final_wash_qty',
                        name: 'final_wash_qty'
                    }, // Column 15
                    {
                        data: 'wash_ratio',
                        name: 'wash_ratio'

                    },
                    {
                        data: 'acid_wash_qty',
                        name: 'acid_wash_qty'
                    }, // Column 14
                    {
                        data: 'rewash_qty',
                        name: 'rewash_qty'
                    }, // Column 16
                    {
                        data: 'rework_dry_proc',
                        name: 'rework_dry_proc'
                    }, // Column 17
                    {
                        data: 'remarks',
                        name: 'remarks', // Column 18
                        render: function(data, type, row) {
                            if (type === 'display') {
                                var remarks = data || '-';
                                var unit = row.unit;
                                var remarkId = 'remark_' + unit.replace(/[^a-zA-Z0-9]/g, '_');

                                // For Unit 4, we want to show a cleaner display
                                if (unit === 'Unit 4') {
                                    // If remarks contain " | ", it means there are different remarks
                                    if (remarks.includes(' | ')) {
                                        // Show the first part as main remark with indicator
                                        var mainRemark = remarks.split(' | ')[0];
                                        return '<div class="d-flex align-items-center justify-content-center">' +
                                            '<span id="' + remarkId +
                                            '_text" class="remark-text me-2" style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="' +
                                            remarks + '">' + mainRemark +
                                            ' <i class="fa-solid fa-chevron-down" style="font-size: 10px;"></i></span>' +
                                            '<button type="button" class="btn btn-sm btn-outline-primary remark-toggle-btn" ' +
                                            'data-unit="' + unit + '" ' +
                                            'data-date="' + today + '" ' +
                                            'data-remark="' + remarks.replace(/"/g, '&quot;') +
                                            '" ' +
                                            'data-target="' + remarkId + '">' +
                                            '<i class="fa-solid fa-pen"></i>' +
                                            '</button>' +
                                            '</div>';
                                    } else {
                                        // Single remark for Unit 4
                                        return '<div class="d-flex align-items-center justify-content-center">' +
                                            '<span id="' + remarkId +
                                            '_text" class="remark-text me-2" style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="' +
                                            remarks + '">' + remarks + '</span>' +
                                            '<button type="button" class="btn btn-sm btn-outline-primary remark-toggle-btn" ' +
                                            'data-unit="' + unit + '" ' +
                                            'data-date="' + today + '" ' +
                                            'data-remark="' + remarks.replace(/"/g, '&quot;') +
                                            '" ' +
                                            'data-target="' + remarkId + '">' +
                                            '<i class="fa-solid fa-pen"></i>' +
                                            '</button>' +
                                            '</div>';
                                    }
                                } else {
                                    // Regular units
                                    return '<div class="d-flex align-items-center justify-content-center">' +
                                        '<span id="' + remarkId +
                                        '_text" class="remark-text me-2" style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="' +
                                        remarks + '">' + remarks + '</span>' +
                                        '<button type="button" class="btn btn-sm btn-outline-primary remark-toggle-btn" ' +
                                        'data-unit="' + unit + '" ' +
                                        'data-date="' + today + '" ' +
                                        'data-remark="' + remarks.replace(/"/g, '&quot;') + '" ' +
                                        'data-target="' + remarkId + '">' +
                                        '<i class="fa-solid fa-pen"></i>' +
                                        '</button>' +
                                        '</div>';
                                }
                            }
                            return data;
                        }
                    }
                ],
                footerCallback: function(row, data, start, end, display) {
                    var api = this.api();

                    // Initialize totals
                    var totalUsedMc = 0; // CHANGED: from totalMachines
                    var totalUsedCapacity = 0; // CHANGED: from totalCapacity
                    var totalDirect = 0;
                    var totalIndirect = 0;
                    var totalTotal = 0;
                    var totalWorkHours = 0;
                    var totalSMV = 0;
                    var totalReceived = 0;
                    var totalDelivery = 0;
                    var totalFirstWash = 0;
                    var totalAcidWash = 0;
                    var totalFinalWash = 0;
                    var totalReWash = 0;
                    var totalReworkDryProc = 0;
                    var totalForecastTarget = 0;
                    var totalDeviation = 0;
                    var totalDeviationPercent = 0;
                    var totalWashRatio = 0;
                    var totalRewashPercent = 0;
                    var totalInHandBalance = 0;
                    var rowCount = 0;

                    // Helper function to parse numbers safely
                    function parseNumber(value) {
                        if (value === null || value === undefined || value === '') return 0;

                        // If it's a string, remove HTML tags and commas, then parse
                        if (typeof value === 'string') {
                            // Remove HTML tags like <span> and any attributes
                            var textValue = value.replace(/<[^>]*>/g, '');
                            // Remove commas from formatted numbers
                            textValue = textValue.replace(/,/g, '');
                            // Remove percentage sign if present
                            textValue = textValue.replace(/%/g, '');
                            // Parse as float
                            var num = parseFloat(textValue);
                            return isNaN(num) ? 0 : num;
                        }

                        // If it's already a number
                        var num = parseFloat(value);
                        return isNaN(num) ? 0 : num;
                    }

                    // Helper function to format numbers with commas
                    function formatNumber(num) {
                        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }

                    // Get all data for the current page
                    var pageData = api.rows({
                        page: 'current'
                    }).data();

                    // Loop through each row and add values
                    for (var i = 0; i < pageData.length; i++) {
                        var row = pageData[i];
                        rowCount++;

                        totalUsedMc += parseNumber(row.used_mc); // CHANGED
                        totalUsedCapacity += parseNumber(row.used_capacity_kg); // CHANGED
                        totalDirect += parseNumber(row.direct);
                        totalIndirect += parseNumber(row.indirect);
                        totalTotal += parseNumber(row.total);
                        totalWorkHours += parseNumber(row.work_hours);
                        totalSMV += parseNumber(row.smv);
                        totalReceived += parseNumber(row.received);
                        totalDelivery += parseNumber(row.delivery);
                        totalFirstWash += parseNumber(row.first_wash_qty);
                        totalAcidWash += parseNumber(row.acid_wash_qty);
                        totalFinalWash += parseNumber(row.final_wash_qty);
                        totalReWash += parseNumber(row.rewash_qty);
                        totalReworkDryProc += parseNumber(row.rework_dry_proc);
                        totalForecastTarget += parseNumber(row.forecast_target);
                        totalDeviation += parseNumber(row.deviation);
                        totalDeviationPercent += parseNumber(row.deviation_percent);
                        totalWashRatio += parseNumber(row.wash_ratio);
                        totalRewashPercent += parseNumber(row.rewash_percent);
                        totalInHandBalance += parseNumber(row.in_hand_balance);
                    }

                    // Calculate averages for ratio columns
                    var avgWashRatio = rowCount > 0 ? totalWashRatio / rowCount : 0;
                    var avgRewashPercent = rowCount > 0 ? totalRewashPercent / rowCount : 0;

                    // Update footer with formatted values
                    $('#footerMachines').text(formatNumber(Math.round(
                        totalUsedMc))); // CHANGED: Now shows Used MC total
                    $('#footerCapacity').text(formatNumber(Math.round(totalUsedCapacity)) +
                        ' kg'); // CHANGED: Now shows Used Capacity total
                    $('#footerDirect').text(formatNumber(Math.round(totalDirect)));
                    $('#footerIndirect').text(formatNumber(Math.round(totalIndirect)));
                    $('#footerTotal').text(formatNumber(Math.round(totalTotal)));
                    $('#footerWorkHours').text(totalWorkHours.toFixed(2));
                    $('#footerSMV').text(totalSMV.toFixed(2));
                    $('#footerReceived').text(formatNumber(Math.round(totalReceived)));
                    $('#footerDelivery').text(formatNumber(Math.round(totalDelivery)));
                    $('#footerGarment').text('-');
                    $('#footerForecastTarget').text(formatNumber(Math.round(totalForecastTarget)));
                    $('#footerDeviation').text(formatNumber(Math.round(totalDeviation)));
                    $('#footerDeviationPercent').text(formatNumber(Math.round(totalDeviationPercent)) +
                        '%');
                    $('#footerWashRatio').text(avgWashRatio.toFixed(2) + '%');
                    $('#footerRewashPercent').text(avgRewashPercent.toFixed(2) + '%');
                    $('#footerInHandBalance').text(formatNumber(Math.round(totalInHandBalance)));
                    $('#footerFirstWash').text(formatNumber(Math.round(totalFirstWash)));
                    $('#footerAcidWash').text(formatNumber(Math.round(totalAcidWash)));
                    $('#footerFinalWash').text(formatNumber(Math.round(totalFinalWash)));
                    $('#footerReWash').text(formatNumber(Math.round(totalReWash)));
                    $('#footerReworkDryProc').text(formatNumber(Math.round(totalReworkDryProc)));
                    $('#footerRemarks').text('-');
                }
            });

            // Initialize First Dry Process DataTable
            var firstDryTable = $('#firstDryProcessTable').DataTable({
                responsive: true,
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ route('admin.wash-report-dashboard.first-dry-process') }}",
                    type: 'GET',
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                    }
                },
                paging: true,
                pageLength: 10,
                searching: false,
                info: true,
                ordering: false,
                columns: [{
                        data: 'plant',
                        name: 'plant'
                    },
                    {
                        data: 'whisker_target',
                        name: 'whisker_target'
                    },
                    {
                        data: 'whisker_production',
                        name: 'whisker_production'
                    },
                    {
                        data: 'handbrush_target',
                        name: 'handbrush_target'
                    },
                    {
                        data: 'handbrush_production',
                        name: 'handbrush_production'
                    },
                    {
                        data: 'firstdryfinal_target',
                        name: 'firstdryfinal_target'
                    },
                    {
                        data: 'firstdryfinal_production',
                        name: 'firstdryfinal_production'
                    },
                    {
                        data: 'deviation',
                        name: 'deviation'
                    },
                    {
                        data: 'defect_qty',
                        name: 'defect_qty'
                    },
                    {
                        data: 'manPower',
                        name: 'manPower'
                    },
                    {
                        data: 'workingHr',
                        name: 'workingHr'
                    },
                    {
                        data: 'smv',
                        name: 'smv'
                    }
                ],
                footerCallback: function(row, data, start, end, display) {
                    var api = this.api();

                    // Initialize totals
                    var totalWhiskerTarget = 0;
                    var totalWhiskerProd = 0;
                    var totalHandbrushTarget = 0;
                    var totalHandbrushProd = 0;
                    var totalFirstDryTarget = 0;
                    var totalFirstDryProd = 0;
                    var totalDeviation = 0;
                    var totalDefectQty = 0;
                    var totalManpower = 0;

                    // Helper function to parse numbers safely
                    function parseNumber(value) {
                        if (value === null || value === undefined || value === '') return 0;
                        if (typeof value === 'number') return value;
                        var strValue = String(value).replace(/<[^>]*>/g, '').replace(/,/g, '');
                        var num = parseFloat(strValue);
                        return isNaN(num) ? 0 : num;
                    }

                    // Helper function to format numbers with commas
                    function formatNumber(num) {
                        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }

                    // Get all data for the current page
                    var pageData = api.rows({
                        page: 'current'
                    }).data();

                    // Loop through each row and add values from raw data
                    for (var i = 0; i < pageData.length; i++) {
                        var row = pageData[i];

                        totalWhiskerTarget += parseNumber(row.whisker_target);
                        totalWhiskerProd += parseNumber(row.whisker_production);
                        totalHandbrushTarget += parseNumber(row.handbrush_target);
                        totalHandbrushProd += parseNumber(row.handbrush_production);
                        totalFirstDryTarget += parseNumber(row.firstdryfinal_target);
                        totalFirstDryProd += parseNumber(row.firstdryfinal_production);
                        totalDeviation += parseNumber(row.firstdryfinal_deviation);
                        totalDefectQty += parseNumber(row.total_defect_qty);
                        totalManpower += parseNumber(row.manPower);
                    }

                    // Update footer with formatted values (with commas)
                    $('#footerWhiskerTarget').text(formatNumber(Math.round(totalWhiskerTarget)));
                    $('#footerWhiskerProd').text(formatNumber(Math.round(totalWhiskerProd)));
                    $('#footerHandbrushTarget').text(formatNumber(Math.round(totalHandbrushTarget)));
                    $('#footerHandbrushProd').text(formatNumber(Math.round(totalHandbrushProd)));
                    $('#footerFirstDryTarget').text(formatNumber(Math.round(totalFirstDryTarget)));
                    $('#footerFirstDryProd').text(formatNumber(Math.round(totalFirstDryProd)));
                    $('#footerFirstManpower').text(formatNumber(Math.round(totalManpower)));

                    // Set Working Hours and SMV to dash
                    $('#footerFirstWorkingHr').text('-');
                    $('#footerFirstSmv').text('-');

                    // Update the deviation and defect cells in footer
                    var footerCells = $(api.table().footer()).find('th');
                    if (footerCells.length > 7) {
                        $(footerCells[7]).html(formatNumber(Math.round(
                            totalDeviation))); // deviation column
                    }
                    if (footerCells.length > 8) {
                        $(footerCells[8]).html(formatNumber(Math.round(
                            totalDefectQty))); // defect column
                    }
                }
            });

            // Initialize Second Dry Process DataTable
            var secondDryTable = $('#secondDryProcessTable').DataTable({
                responsive: true,
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ route('admin.wash-report-dashboard.second-dry-process') }}",
                    type: 'GET',
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                    }
                },
                paging: true,
                pageLength: 10,
                searching: false,
                info: true,
                ordering: false,
                columns: [{
                        data: 'plant',
                        name: 'plant'
                    },
                    {
                        data: 'laser_target',
                        name: 'laser_target'
                    },
                    {
                        data: 'laser_production',
                        name: 'laser_production'
                    },
                    {
                        data: 'ppspray_target',
                        name: 'ppspray_target'
                    },
                    {
                        data: 'ppspray_production',
                        name: 'ppspray_production'
                    },
                    {
                        data: 'seconddryfinal_target',
                        name: 'seconddryfinal_target'
                    },
                    {
                        data: 'seconddryfinal_production',
                        name: 'seconddryfinal_production'
                    },
                    {
                        data: 'deviation',
                        name: 'deviation'
                    },
                    {
                        data: 'defect_qty',
                        name: 'defect_qty'
                    },
                    {
                        data: 'manPower',
                        name: 'manPower'
                    },
                    {
                        data: 'workingHr',
                        name: 'workingHr'
                    },
                    {
                        data: 'smv',
                        name: 'smv'
                    }
                ],

                footerCallback: function(row, data, start, end, display) {
                    var api = this.api();

                    // Initialize totals
                    var totalLaserTarget = 0;
                    var totalLaserProd = 0;
                    var totalPpTarget = 0;
                    var totalPpProd = 0;
                    var totalSecondDryTarget = 0;
                    var totalSecondDryProd = 0;
                    var totalDeviation = 0;
                    var totalDefectQty = 0;
                    var totalManpower = 0;

                    // Helper function to parse numbers safely
                    function parseNumber(value) {
                        if (value === null || value === undefined || value === '') return 0;
                        if (typeof value === 'number') return value;
                        // Remove HTML tags and commas, then parse
                        var strValue = String(value).replace(/<[^>]*>/g, '').replace(/,/g, '');
                        var num = parseFloat(strValue);
                        return isNaN(num) ? 0 : num;
                    }

                    // Helper function to format numbers with commas
                    function formatNumber(num) {
                        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }

                    // Get all data for the current page (raw data from server)
                    var pageData = api.rows({
                        page: 'current'
                    }).data();

                    console.log('2nd Dry Process Page Data:', pageData); // Debug log

                    // Loop through each row and add values from raw data
                    for (var i = 0; i < pageData.length; i++) {
                        var row = pageData[i];

                        totalLaserTarget += parseNumber(row.laser_target);
                        totalLaserProd += parseNumber(row.laser_production);
                        totalPpTarget += parseNumber(row.ppspray_target);
                        totalPpProd += parseNumber(row.ppspray_production);
                        totalSecondDryTarget += parseNumber(row.seconddryfinal_target);
                        totalSecondDryProd += parseNumber(row.seconddryfinal_production);
                        totalDeviation += parseNumber(row.seconddryfinal_deviation);
                        totalDefectQty += parseNumber(row.total_defect_qty);
                        totalManpower += parseNumber(row.manPower);

                        console.log(
                            `Row ${i} - Plant: ${row.plant}, Deviation: ${row.seconddryfinal_deviation}, Defect: ${row.total_defect_qty}`
                        );
                    }

                    console.log('2nd Dry Process Totals:', {
                        laserTarget: totalLaserTarget,
                        laserProd: totalLaserProd,
                        ppTarget: totalPpTarget,
                        ppProd: totalPpProd,
                        secondDryTarget: totalSecondDryTarget,
                        secondDryProd: totalSecondDryProd,
                        deviation: totalDeviation,
                        defectQty: totalDefectQty,
                        manpower: totalManpower
                    });

                    // Update footer with formatted values (with commas)
                    $('#footerLaserTarget').text(formatNumber(Math.round(totalLaserTarget)));
                    $('#footerLaserProd').text(formatNumber(Math.round(totalLaserProd)));
                    $('#footerPpTarget').text(formatNumber(Math.round(totalPpTarget)));
                    $('#footerPpProd').text(formatNumber(Math.round(totalPpProd)));
                    $('#footerSecondDryTarget').text(formatNumber(Math.round(totalSecondDryTarget)));
                    $('#footerSecondDryProd').text(formatNumber(Math.round(totalSecondDryProd)));
                    $('#footerSecondManpower').text(formatNumber(Math.round(totalManpower)));

                    // Set Working Hours and SMV to dash
                    $('#footerSecondWorkingHr').text('-');
                    $('#footerSecondSmv').text('-');

                    // Update the deviation and defect cells in footer
                    // Find the deviation cell (7th column) and defect cell (8th column)
                    var footerCells = $(api.table().footer()).find('th');
                    if (footerCells.length > 7) {
                        $(footerCells[7]).html(formatNumber(Math.round(
                            totalDeviation))); // deviation column
                    }
                    if (footerCells.length > 8) {
                        $(footerCells[8]).html(formatNumber(Math.round(
                            totalDefectQty))); // defect column
                    }
                }
            });

            // Initialize Transfer DataTable with simple design
            var transferTable = $('#transferDataTable').DataTable({
                responsive: true,
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ route('admin.wash-report-dashboard.transfer-data') }}",
                    type: 'GET',
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                    },
                    dataSrc: function(json) {
                        // Update summary badges
                        if (json.summary) {
                            $('#totalTransfersBadge').text('Total: ' + json.summary.total_transfers);
                            $('#verifiedTransfersBadge').text('✓ ' + json.summary.verified_transfers);
                            $('#pendingTransfersBadge').text('⏳ ' + json.summary.pending_transfers);
                            $('#rejectedTransfersBadge').text('✗ ' + json.summary.rejected_transfers);
                        }
                        return json.data;
                    }
                },
                paging: true,
                pageLength: 10,
                searching: true,
                info: true,
                ordering: true,
                order: [
                    [0, 'asc']
                ], // Sort by unit name ascending
                columns: [{
                        data: 'unit',
                        name: 'unit'
                    }, // Column 0
                    {
                        data: 'existing_mc',
                        name: 'existing_mc'
                    }, // Column 1
                    {
                        data: 'used_mc',
                        name: 'used_mc'
                    }, // Column 2
                    {
                        data: 'transfer_in_details',
                        name: 'transfer_in_details'
                    }, // Column 3
                    {
                        data: 'transfer_out_details',
                        name: 'transfer_out_details'
                    }, // Column 4
                    {
                        data: 'base_mg_target',
                        name: 'base_mg_target'
                    }, // Column 5
                    {
                        data: 'current_mg_target',
                        name: 'current_mg_target'
                    }, // Column 6
                    {
                        data: 'base_capacity_pieces',
                        name: 'base_capacity_pieces'
                    }, // Column 7
                    {
                        data: 'current_capacity_pieces',
                        name: 'current_capacity_pieces'
                    }, // Column 8
                    {
                        data: 'base_capacity_kg',
                        name: 'base_capacity_kg'
                    }, // Column 9
                    {
                        data: 'current_capacity_kg',
                        name: 'current_capacity_kg'
                    } // Column 10
                ],
                footerCallback: function(row, data, start, end, display) {
                    var api = this.api();

                    // Initialize totals
                    var totalExistingMc = 0;
                    var totalUsedMc = 0;
                    var totalBaseMg = 0;
                    var totalCurrentMg = 0;
                    var totalBasePcs = 0;
                    var totalCurrentPcs = 0;
                    var totalBaseKg = 0;
                    var totalCurrentKg = 0;

                    // Helper function to parse numbers safely
                    function parseNumber(value) {
                        if (value === null || value === undefined || value === '') return 0;
                        if (typeof value === 'number') return value;
                        var strValue = String(value).replace(/,/g, '');
                        var num = parseFloat(strValue);
                        return isNaN(num) ? 0 : num;
                    }

                    // Helper function to format numbers with commas
                    function formatNumber(num) {
                        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }

                    // Helper function to return dash if zero, otherwise formatted number
                    function formatValue(num) {
                        return num === 0 ? '-' : formatNumber(Math.round(num));
                    }

                    // Get all data for the current page
                    var pageData = api.rows({
                        page: 'current'
                    }).data();

                    // Loop through each row and add values
                    for (var i = 0; i < pageData.length; i++) {
                        var row = pageData[i];

                        totalExistingMc += parseNumber(row.existing_mc);
                        totalUsedMc += parseNumber(row.used_mc);
                        totalBaseMg += parseNumber(row.base_mg_target);
                        totalCurrentMg += parseNumber(row.current_mg_target);
                        totalBasePcs += parseNumber(row.base_capacity_pieces);
                        totalCurrentPcs += parseNumber(row.current_capacity_pieces);
                        totalBaseKg += parseNumber(row.base_capacity_kg);
                        totalCurrentKg += parseNumber(row.current_capacity_kg);
                    }

                    // Update footer with formatted values (dash if zero)
                    $('#footerExistingMc').text(formatValue(totalExistingMc));
                    $('#footerUsedMc').text(formatValue(totalUsedMc));
                    $('#footerBaseMg').text(formatValue(totalBaseMg));
                    $('#footerCurrentMg').text(formatValue(totalCurrentMg));
                    $('#footerBasePcs').text(formatValue(totalBasePcs));
                    $('#footerCurrentPcs').text(formatValue(totalCurrentPcs));
                    $('#footerBaseKg').text(formatValue(totalBaseKg));
                    $('#footerCurrentKg').text(formatValue(totalCurrentKg));

                    // Keep the transfer in/out footers as dash
                    $('#footerTransferIn').text('-');
                    $('#footerTransferOut').text('-');
                }
            });

            // Initialize Dryer DataTable

            // Initialize Dryer DataTable
            var dryerTable = $('#dryerDataTable').DataTable({
                responsive: true,
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ route('admin.wash-report-dashboard.dryer-data') }}",
                    type: 'GET',
                    data: function(d) {
                        d.from_date = $('#from_date').val();
                        d.to_date = $('#to_date').val();
                    }
                },
                paging: true,
                pageLength: 10,
                searching: false,
                info: true,
                ordering: false,
                columns: [{
                        data: 'unit',
                        name: 'unit'
                    }, // Column 0
                    {
                        data: 'num_dryer',
                        name: 'num_dryer'
                    }, // Column 1
                    {
                        data: 'avg_batch',
                        name: 'avg_batch'
                    }, // Column 2
                    {
                        data: 'avg_dryer_time',
                        name: 'avg_dryer_time'
                    }, // Column 3
                    {
                        data: 'capacity',
                        name: 'capacity'
                    }, // Column 4
                    // { data: 'target_qty', name: 'target_qty' },     // Column 5 - COMMENTED OUT
                    {
                        data: 'first_wash_dryer',
                        name: 'first_wash_dryer'
                    }, // Column 5 (was 6)
                    {
                        data: 'cold_dryer',
                        name: 'cold_dryer'
                    }, // Column 6 (was 7)
                    {
                        data: 'measurement_correction',
                        name: 'measurement_correction'
                    }, // Column 7 (was 8)
                    {
                        data: 'final_wash_dryer',
                        name: 'final_wash_dryer'
                    }, // Column 8 (was 9)
                    {
                        data: 'deviation',
                        name: 'deviation'
                    }, // Column 9 (was 10)
                    {
                        data: 'total_dryer',
                        name: 'total_dryer'
                    } // Column 10 (was 11)
                ],

                footerCallback: function(row, data, start, end, display) {
                    var api = this.api();

                    var totalNumDryer = 0;
                    var totalAvgBatch = 0;
                    var totalAvgDryerTime = 0;
                    var totalCapacity = 0;
                    // var totalTargetQty = 0; // COMMENTED OUT
                    var totalFirstWash = 0;
                    var totalColdDryer = 0;
                    var totalMeasCorrection = 0;
                    var totalFinalWash = 0;
                    var totalDeviation = 0;
                    var totalDryer = 0;

                    // Get all data for the current page
                    var pageData = api.rows({
                        page: 'current'
                    }).data();

                    for (var i = 0; i < pageData.length; i++) {
                        var row = pageData[i];

                        var deviationValue = row.deviation_raw !== undefined ? row.deviation_raw : row
                            .deviation;

                        totalNumDryer += Number(row.num_dryer) || 0;
                        totalAvgBatch += Number(row.avg_batch) || 0;
                        totalAvgDryerTime += Number(row.avg_dryer_time) || 0;
                        totalCapacity += Number(row.capacity) || 0;
                        // totalTargetQty += Number(row.target_qty) || 0; // COMMENTED OUT
                        totalFirstWash += Number(row.first_wash_dryer) || 0;
                        totalColdDryer += Number(row.cold_dryer) || 0;
                        totalMeasCorrection += Number(row.measurement_correction) || 0;
                        totalFinalWash += Number(row.final_wash_dryer) || 0;
                        totalDeviation += Number(deviationValue) || 0;
                        totalDryer += Number(row.total_dryer) || 0;
                    }

                    // Update footer with formatted values (Target column removed)
                    $('#footerNumDryer').text(Math.round(totalNumDryer));
                    $('#footerAvgBatch').text(totalAvgBatch.toFixed(2));
                    $('#footerAvgDryerTime').text(totalAvgDryerTime.toFixed(2));
                    $('#footerCapacity').text(totalCapacity.toFixed(2));
                    // $('#footerTargetQty').text(Math.round(totalTargetQty)); // COMMENTED OUT
                    $('#footerFirstWashDryer').text(Math.round(totalFirstWash));
                    $('#footerColdDryer').text(Math.round(totalColdDryer));
                    $('#footerMeasCorrection').text(Math.round(totalMeasCorrection));
                    $('#footerFinalWashDryer').text(Math.round(totalFinalWash));
                    $('#footerDeviation').text(Math.round(totalDeviation));
                    $('#footerTotalDryer').text(Math.round(totalDryer));
                }
            });

            // Function to update date range display
            function updateDateRange() {
                var fromDate = $('#from_date').val();
                var toDate = $('#to_date').val();
                if (fromDate && toDate) {
                    var formattedFrom = formatDate(fromDate);
                    var formattedTo = formatDate(toDate);

                    if (fromDate === toDate) {
                        $('#dateRange').text(formattedFrom);
                    } else {
                        $('#dateRange').text(formattedFrom + ' to ' + formattedTo);
                    }
                }
            }

            // Helper function to format date
            function formatDate(dateString) {
                var date = new Date(dateString);
                var day = ('0' + date.getDate()).slice(-2);
                var month = ('0' + (date.getMonth() + 1)).slice(-2);
                var year = date.getFullYear();
                return day + '-' + month + '-' + year;
            }

            // Filter form submission
            $('#filter_form').on('submit', function(e) {
                e.preventDefault();
                updateDateRange();
                mainTable.ajax.reload();
                firstDryTable.ajax.reload();
                secondDryTable.ajax.reload();
                dryerTable.ajax.reload();
                transferTable.ajax.reload();
            });

            // Reset filter - set to today
            $('#resetBtn').on('click', function() {
                $('#from_date').val(today);
                $('#to_date').val(today);
                updateDateRange();
                mainTable.ajax.reload();
                firstDryTable.ajax.reload();
                secondDryTable.ajax.reload();
                dryerTable.ajax.reload();
                transferTable.ajax.reload();
            });

            // Set today's data (both from and to as today)
            $('#todayBtn').on('click', function() {
                $('#from_date').val(today);
                $('#to_date').val(today);
                updateDateRange();
                mainTable.ajax.reload();
                firstDryTable.ajax.reload();
                secondDryTable.ajax.reload();
                dryerTable.ajax.reload();
                transferTable.ajax.reload();
            });

            // Refresh button
            $('#refreshBtn').on('click', function() {
                mainTable.ajax.reload(null, false);
                firstDryTable.ajax.reload(null, false);
                secondDryTable.ajax.reload(null, false);
                dryerTable.ajax.reload(null, false);
                transferTable.ajax.reload(null, false);
            });

            // Handle date change events to update display
            $('#from_date, #to_date').on('change', function() {
                updateDateRange();
            });

            // Remarks toggle button click handler
            $(document).on('click', '.remark-toggle-btn', function() {
                var unit = $(this).data('unit');
                var date = $(this).data('date');
                var remark = $(this).data('remark');

                // Format date for display
                var formattedDate = formatDate(date);

                // Set modal fields
                $('#remark_unit').val(unit);
                $('#remark_date').val(date);
                $('#unit_display').val(unit);
                $('#date_display').val(formattedDate);
                $('#remark_text').val(remark !== '-' ? remark : '');
                $('#remark_id').val('');

                // Show modal
                $('#remarkModal').modal('show');
            });

            // Save remark button click handler
            $('#saveRemarkBtn').on('click', function() {
                var unit = $('#remark_unit').val();
                var date = $('#remark_date').val();
                var remark = $('#remark_text').val().trim();
                var id = $('#remark_id').val();

                if (!remark) {
                    alert('Please enter a remark');
                    return;
                }

                var url = id ? "{{ route('admin.wash-report-dashboard.update-remark') }}" :
                    "{{ route('admin.wash-report-dashboard.save-remark') }}";
                var data = id ? {
                    id: id,
                    remark: remark
                } : {
                    unit: unit,
                    date: date,
                    remark: remark
                };

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: data,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.success) {
                            // Show success message
                            if (typeof $.toast === 'function') {
                                $.toast({
                                    heading: 'Success',
                                    text: response.message,
                                    position: 'top-center',
                                    icon: 'success',
                                    loader: false
                                });
                            } else {
                                alert('Success: ' + response.message);
                            }

                            // Close modal
                            $('#remarkModal').modal('hide');

                            // Reload table to show updated remark
                            mainTable.ajax.reload(null, false);
                        }
                    },
                    error: function(xhr) {
                        var errorMessage = 'Error saving remark';
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            errorMessage = xhr.responseJSON.message;
                        }

                        if (typeof $.toast === 'function') {
                            $.toast({
                                heading: 'Error',
                                text: errorMessage,
                                position: 'top-center',
                                icon: 'error',
                                loader: false
                            });
                        } else {
                            alert('Error: ' + errorMessage);
                        }
                    }
                });
            });

            // View remarks history (double click on remark cell)
            $(document).on('dblclick', '.remark-text', function() {
                var unit = $(this).closest('tr').find('td:first-child').text().trim();

                $('#history_unit_name').text('Remarks History for ' + unit);
                $('#remarksHistoryBody').html(
                    '<tr><td colspan="3" class="text-center">Loading...</td></tr>');

                $.ajax({
                    url: "{{ url('admin/dashboard-two/get-remarks') }}/" + encodeURIComponent(unit),
                    type: 'GET',
                    success: function(response) {
                        if (response.success && response.data.length > 0) {
                            var html = '';
                            $.each(response.data, function(index, item) {
                                var formattedDate = formatDate(item.date);
                                html += '<tr>';
                                html += '<td class="text-center">' + formattedDate +
                                    '</td>';
                                html += '<td>' + item.Remarks + '</td>';
                                html += '<td class="text-center">';
                                html +=
                                    '<button type="button" class="btn btn-sm btn-outline-primary edit-history-remark me-1" data-id="' +
                                    item.id + '" data-remark="' + item.Remarks.replace(
                                        /"/g, '&quot;') +
                                    '"><i class="fa-solid fa-pen"></i></button>';
                                html += '</td>';
                                html += '</tr>';
                            });
                            $('#remarksHistoryBody').html(html);
                        } else {
                            $('#remarksHistoryBody').html(
                                '<tr><td colspan="3" class="text-center text-muted">No remarks found</td></tr>'
                            );
                        }
                        $('#remarksHistoryModal').modal('show');
                    },
                    error: function() {
                        $('#remarksHistoryBody').html(
                            '<tr><td colspan="3" class="text-center text-danger">Error loading remarks</td></tr>'
                        );
                    }
                });
            });

            // Edit remark from history
            $(document).on('click', '.edit-history-remark', function() {
                var id = $(this).data('id');
                var remark = $(this).data('remark');
                var unit = $('#history_unit_name').text().replace('Remarks History for ', '');

                $('#remark_id').val(id);
                $('#remark_text').val(remark);
                $('#unit_display').val(unit);
                $('#remark_unit').val(unit);
                $('#date_display').val('');

                $('#remarksHistoryModal').modal('hide');
                $('#remarkModal').modal('show');
            });

            // PDF Download functionality
            $('#downloadPdfBtn').on('click', function() {
                // Show loading indicator
                Swal.fire({
                    title: 'Generating PDF...',
                    text: 'Please wait while we prepare your report.',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                // Get current filter values
                var fromDate = $('#from_date').val();
                var toDate = $('#to_date').val();

                // Create a form and submit to generate PDF
                var form = $('<form>', {
                    'method': 'POST',
                    'action': "{{ route('admin.wash-report-dashboard.download-pdf') }}"
                });

                form.append($('<input>', {
                    'name': '_token',
                    'value': '{{ csrf_token() }}',
                    'type': 'hidden'
                }));

                form.append($('<input>', {
                    'name': 'from_date',
                    'value': fromDate,
                    'type': 'hidden'
                }));

                form.append($('<input>', {
                    'name': 'to_date',
                    'value': toDate,
                    'type': 'hidden'
                }));

                $('body').append(form);
                form.submit();
                form.remove();

                // Close loading after a delay (PDF will download separately)
                setTimeout(() => {
                    Swal.close();
                }, 3000);
            });
        });
    </script>

    {{-- For chart script --}}

    <script>
        // Simple Chart.js implementation for CAPP data with per-unit data
        // Function to load chart data
        function loadCappChart() {
            var fromDate = $('#from_date').val();
            var toDate = $('#to_date').val();

            $.ajax({
                url: "{{ route('admin.wash-report-dashboard.capp-machine-status') }}",
                type: 'GET',
                data: {
                    from_date: fromDate,
                    to_date: toDate
                },
                success: function(response) {
                    if (response.success) {
                        // Update period fields
                        $('#cappFrom').text(response.period.from || '-');
                        $('#cappTo').text(response.period.to || '-');

                        // Destroy existing chart if it exists
                        if (window.cappChart instanceof Chart) {
                            window.cappChart.destroy();
                        }

                        // Create new chart
                        const ctx = document.getElementById('cappChart').getContext('2d');
                        window.cappChart = new Chart(ctx, {
                            type: 'bar',
                            data: response.chart_data,
                            options: {
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        max: 100,
                                        title: {
                                            display: true,
                                            text: 'Percentage (%)'
                                        },
                                        ticks: {
                                            callback: function(value) {
                                                return value + '%';
                                            }
                                        }
                                    }
                                },
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        position: 'top',
                                    }
                                },
                                barPercentage: 0.7,
                                categoryPercentage: 0.8
                            }
                        });
                        // Calculate and display summary averages
                        if (response.unit_data) {
                            let totalUptime = 0;
                            let totalIdletime = 0;
                            let totalDowntime = 0;
                            let unitCount = 0;

                            // Sum up all values
                            Object.values(response.unit_data).forEach(unit => {
                                totalUptime += unit.uptime || 0;
                                totalIdletime += unit.idletime || 0;
                                totalDowntime += unit.downtime || 0;
                                unitCount++;
                            });

                            // Calculate averages
                            if (unitCount > 0) {
                                const avgUptime = (totalUptime / unitCount).toFixed(2);
                                const avgIdletime = (totalIdletime / unitCount).toFixed(2);
                                const avgDowntime = (totalDowntime / unitCount).toFixed(2);

                                // Update the summary text elements
                                $('#uptimeValueDetail').text(avgUptime);
                                $('#idletimeValueDetail').text(avgIdletime);
                                $('#downtimeValueDetail').text(avgDowntime);
                            }
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error('API Error:', error);
                }
            });
        }

        // Call on page load
        $(document).ready(function() {
            loadCappChart();

            // Reload when filter is applied
            $('#filter_form').on('submit', function(e) {
                e.preventDefault();
                loadCappChart();
            });

            $('#resetBtn, #todayBtn').on('click', function() {
                loadCappChart();
            });
        });
    </script>
@endpush