<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wash Report Dashboard</title>
    <style>
        body {
            font-family: 'Helvetica', 'Arial', sans-serif;
            font-size: 8px;
            /* Increased base size */
            margin: 0;
            padding: 0;
            color: #222;
        }

        /* Prevent page breaks inside elements */
        .page-break-avoid {
            page-break-inside: avoid;
            page-break-before: auto;
            page-break-after: auto;
        }

        /* Ensure tables don't break */
        table {
            page-break-inside: avoid;
        }

        /* Make the last section stay on first page */
        .last-section {
            page-break-inside: avoid;
            margin-top: 5px;
        }

        .header {
            text-align: center;
            margin-bottom: 4px;
            border-bottom: 1px solid #000;
            padding-bottom: 2px;
        }

        .header h2 {
            margin: 0;
            font-size: 13px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .header p {
            margin: 2px 0 0 0;
            font-size: 9px;
            color: #555;
        }

        table {
            border-collapse: collapse;
            font-size: 7.5px;
            /* Increased from 6px */
        }

        .layout-table {
            width: 100%;
            border: none;
            margin-bottom: 5px;
            /* Increased margin */
        }

        .layout-table td {
            vertical-align: top;
            padding: 0 3px;
        }

        .data-table {
            width: 100%;
            border: 0.5px solid #999;
        }

        .data-table th,
        .data-table td {
            border: 0.5px solid #999;
            padding: 3px 4px;
            /* Increased padding for height */
            text-align: center;
            vertical-align: middle;
        }

        .data-table th {
            background-color: #e9ecef;
            font-weight: bold;
            font-size: 7.5px;
        }

        .data-table tfoot th {
            background-color: #d1d5db;
            font-weight: bold;
            font-size: 7.5px;
            border-top: 1px solid #666;
        }

        .data-table tfoot td {
            background-color: #f3f4f6;
            font-weight: bold;
            font-size: 7.5px;
            border-top: 1px solid #666;
        }

        .data-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .section-title {
            font-size: 8.5px;
            /* Increased slightly */
            font-weight: bold;
            margin-bottom: 2px;
            margin-top: 3px;
            background-color: #f0f0f0;
            padding: 2px 4px;
            border-left: 3px solid #007bff;
            display: block;
        }

        .text-success {
            color: #28a745;
        }

        .text-danger {
            color: #dc3545;
        }

        .text-warning {
            color: #ffc107;
        }

        .fw-bold {
            font-weight: bold;
        }

        .main-table td:nth-child(1) {
            text-align: left;
            font-weight: bold;
        }

        .main-table td:nth-child(4) {
            max-width: 30px;
            overflow: hidden;
            white-space: nowrap;
        }

        .main-table td:last-child {
            max-width: 40px;
            text-align: left;
            font-size: 6.5px;
        }

        .footer {
            position: fixed;
            bottom: 3px;
            width: 100%;
            text-align: center;
            font-size: 6.5px;
            color: #888;
        }
    </style>
</head>

<body>

    <!-- Header -->
    <div class="header" style="position: relative; margin-bottom: 5px;">
        <div style="position: absolute; top: 0; left: 0;">
            <img src="{{ public_path('assets/img/logo.jpeg') }}" alt="Tusuka" style="height: 30px; width: auto;">
        </div>
        <div style="text-align: center; margin-bottom: 5px;">
            <h2>WASH REPORT-DAILY</h2>
            <p>Period: {{ \Carbon\Carbon::parse($fromDate)->format('d-M-Y') }} to
                {{ \Carbon\Carbon::parse($toDate)->format('d-M-Y') }}
            </p>
        </div>
    </div>


    <!-- 1. Main Unit Table -->
    <div style="margin-bottom: 5px;">
        <span class="section-title" style="background-color: #93c8fdce; text-align: center;">Unit Production
            Details</span>
        <table class="data-table main-table">
            <thead>
                <tr>
                    <th>Unit</th>
                    <th>Used<br>MC</th> <!-- Changed from "MC" -->
                    <th>Cap<br>(kg)</th>
                    <th>Sew<br>Lines</th>
                    <th>Dir</th>
                    <th>Ind</th>
                    <th>Total</th>
                    <th>W.Hr</th>
                    <!-- <th>SMV</th> --> <!-- REMOVED - commented out -->
                    <th>Recv</th>
                    <th>Delv</th>
                    <th>Gmt<br>(g)</th>
                    <th>Forcast<br>Tgt</th>
                    <th>Dev</th>
                    <th>Dev%</th>
                    <th>RW%</th>
                    <th>In<br>Hand</th>
                    <th>1st<br>Wash</th>
                    <th>Final<br>Wash</th>
                    <th>Wash<br>WIP %</th>
                    <th>Acid<br>Wash</th>
                    <th>Rewash</th>
                    <th>Rework<br>Dry</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($unitData as $u)
                    <tr>
                        <td>{{ $u->unit }}</td>
                        <td>{{ $u->used_mc ?? $u->machines }}</td> <!-- Changed to use used_mc -->
                        <td>{{ round($u->used_capacity_kg ?? $u->capacity_kg) }}</td>
                        <!-- Optional: use used capacity -->
                        <td style="font-size:6.5px;">{{ $u->sewing_lines }}</td>
                        <td>{{ $u->direct }}</td>
                        <td>{{ $u->indirect }}</td>
                        <td>{{ $u->total }}</td>
                        <td>{{ $u->work_hours }}</td>
                        <!-- <td>{{ $u->smv }}</td> --> <!-- REMOVED -->
                        <td>{{ $u->received }}</td>
                        <td>{{ $u->delivery }}</td>
                        <td>{{ $u->garment }}</td>
                        <td>{{ $u->forecast_target }}</td>
                        <td>{!! $u->deviation !!}</td>
                        <td>{!! $u->deviation_percent !!}</td>
                        <td>{{ $u->rewash_percent }}</td>
                        <td>{{ $u->in_hand_balance }}</td>
                        <td>{{ $u->first_wash_qty }}</td>
                        <td>{{ $u->final_wash_qty }}</td>
                        <td>{{ $u->wash_ratio }}</td>
                        <td>{{ $u->acid_wash_qty }}</td>
                        <td>{{ $u->rewash_qty }}</td>
                        <td>{{ $u->rework_dry_proc }}</td>
                        <td style="text-align:left; font-size:6.5px;">
                            {{ \Illuminate\Support\Str::limit($u->remarks, 20) }}
                        </td>
                    </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>Total</th>
                    <td>{{ number_format($unitTotals['machines']) }}</td>
                    <td>{{ number_format($unitTotals['capacity_kg']) }}</td>
                    <td>-</td>
                    <td>{{ number_format($unitTotals['direct']) }}</td>
                    <td>{{ number_format($unitTotals['indirect']) }}</td>
                    <td>{{ number_format($unitTotals['total']) }}</td>
                    <td>{{ number_format($unitTotals['work_hours'], 1) }}</td>
                    <!-- <td>{{ number_format($unitTotals['smv'], 1) }}</td> --> <!-- REMOVED -->
                    <td>{{ number_format($unitTotals['received']) }}</td>
                    <td>{{ number_format($unitTotals['delivery']) }}</td>
                    <td>-</td>
                    <td>{{ number_format($unitTotals['forecast_target']) }}</td>
                    <td>{{ number_format($unitTotals['deviation']) }}</td>
                    <td>{{ number_format($unitTotals['deviation_percent']) }}%</td>
                    <td>{{ $unitCount > 0 ? number_format($unitTotals['rewash_percent'] / $unitCount, 1) : 0 }}%</td>
                    <td>{{ number_format($unitTotals['in_hand_balance'] ?? 0) }}</td>
                    <td>{{ number_format($unitTotals['first_wash_qty']) }}</td>
                    <td>{{ number_format($unitTotals['final_wash_qty']) }}</td>
                    <td>{{ $unitCount > 0 ? number_format($unitTotals['wash_ratio'] / $unitCount, 1) : 0 }}</td>
                    <td>{{ number_format($unitTotals['acid_wash_qty']) }}</td>
                    <td>{{ number_format($unitTotals['rewash_qty']) }}</td>
                    <td>{{ number_format($unitTotals['rework_dry_proc']) }}</td>
                    <td>-</td>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- 2. Dry Process Tables -->
    <table class="layout-table" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td width="50%" style="padding-right: 3px;">
                <span class="section-title" style="background-color: #93c8fdce; text-align: center;">1st Dry
                    Process</span>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Plant</th>
                            <th colspan="2">Whisker</th>
                            <th colspan="2">Hand Brush</th>
                            <th colspan="2">1st Dry Final</th>
                            <th rowspan="2">Dev</th>
                            <th rowspan="2">Def</th>
                            <th rowspan="2">Man</th>
                            <th rowspan="2">W.Hr</th>
                            <th rowspan="2">SMV</th>
                        </tr>
                        <tr>
                            <th></th>
                            <th>Tgt</th>
                            <th>Prd</th>
                            <th>Tgt</th>
                            <th>Prd</th>
                            <th>Tgt</th>
                            <th>Prd</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($firstDryData as $d)
                            <tr>
                                <td>{{ $d->plant }}</td>
                                <td>{{ $d->whisker_target }}</td>
                                <td>{{ $d->whisker_production }}</td>
                                <td>{{ $d->handbrush_target }}</td>
                                <td>{{ $d->handbrush_production }}</td>
                                <td>{{ $d->firstdryfinal_target }}</td>
                                <td>{{ $d->firstdryfinal_production }}</td>
                                <td>{!! $d->deviation !!}</td>
                                <td>{{ $d->defect_qty }}</td>
                                <td>{{ $d->manPower }}</td>
                                <td>{{ $d->workingHr }}</td>
                                <td>{{ $d->smv }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Total</th>
                            <td>{{ number_format($firstDryTotals['whisker_target'] ?? 0) }}</td>
                            <td>{{ number_format($firstDryTotals['whisker_prod'] ?? 0) }}</td>
                            <td>{{ number_format($firstDryTotals['handbrush_target'] ?? 0) }}</td>
                            <td>{{ number_format($firstDryTotals['handbrush_prod'] ?? 0) }}</td>
                            <td>{{ number_format($firstDryTotals['target'] ?? 0) }}</td>
                            <td>{{ number_format($firstDryTotals['prod'] ?? 0) }}</td>
                            <td>{{ number_format(round($firstDryTotals['deviation'] ?? 0)) }}</td>
                            <td>{{ number_format($firstDryTotals['defect'] ?? 0) }}</td>
                            <td>{{ number_format($firstDryTotals['manpower'] ?? 0) }}</td>
                            <td>-</td>
                            <td>-</td>
                        </tr>
                    </tfoot>
                </table>
            </td>

            <td width="50%" style="padding-left: 3px;">
                <span class="section-title" style="background-color: #93c8fdce; text-align: center;">2nd Dry
                    Process</span>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Plant</th>
                            <th colspan="2">Laser</th>
                            <th colspan="2">PP Spray</th>
                            <th colspan="2">2nd Dry Final</th>
                            <th rowspan="2">Dev</th>
                            <th rowspan="2">Def</th>
                            <th rowspan="2">Man</th>
                            <th rowspan="2">W.Hr</th>
                            <th rowspan="2">SMV</th>
                        </tr>
                        <tr>
                            <th></th>
                            <th>Tgt</th>
                            <th>Prd</th>
                            <th>Tgt</th>
                            <th>Prd</th>
                            <th>Tgt</th>
                            <th>Prd</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($secondDryData as $d)
                            <tr>
                                <td>{{ $d->plant }}</td>
                                <td>{{ $d->laser_target }}</td>
                                <td>{{ $d->laser_production }}</td>
                                <td>{{ $d->ppspray_target }}</td>
                                <td>{{ $d->ppspray_production }}</td>
                                <td>{{ $d->seconddryfinal_target }}</td>
                                <td>{{ $d->seconddryfinal_production }}</td>
                                <td>{!! $d->deviation !!}</td>
                                <td>{{ $d->defect_qty }}</td>
                                <td>{{ $d->manPower }}</td>
                                <td>{{ $d->workingHr }}</td>
                                <td>{{ $d->smv }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Total</th>
                            <td>{{ number_format($secondDryTotals['laser_target'] ?? 0) }}</td>
                            <td>{{ number_format($secondDryTotals['laser_prod'] ?? 0) }}</td>
                            <td>{{ number_format($secondDryTotals['ppspray_target'] ?? 0) }}</td>
                            <td>{{ number_format($secondDryTotals['ppspray_prod'] ?? 0) }}</td>
                            <td>{{ number_format($secondDryTotals['target'] ?? 0) }}</td>
                            <td>{{ number_format($secondDryTotals['prod'] ?? 0) }}</td>
                            <td>{{ number_format(round($secondDryTotals['deviation'] ?? 0)) }}</td>
                            <td>{{ number_format($secondDryTotals['defect'] ?? 0) }}</td>
                            <td>{{ number_format($secondDryTotals['manpower'] ?? 0) }}</td>
                            <td>-</td>
                            <td>-</td>
                        </tr>
                    </tfoot>
                </table>
            </td>
        </tr>
    </table>

    <!-- 3. Transfer & Dryer Tables -->
    <table class="layout-table" cellpadding="0" cellspacing="0" border="0">
        <tr>
            <td width="50%" style="padding-right: 3px;">
                <span class="section-title" style="background-color: #93c8fdce; text-align: center;">Machine Transfer
                    Data</span>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th rowspan="2">Unit</th>
                            <th colspan="2">Machine</th>
                            <th rowspan="2">Trans In</th>
                            <th rowspan="2">Trans Out</th>
                            <th colspan="2">Target</th>
                            <th colspan="2">M Cap. pcs</th>
                            <th colspan="2">M Cap.kg</th>
                        </tr>
                        <tr>
                            <th>Exist</th> <!-- Machine: Existing MC -->
                            <th>Used</th> <!-- Machine: Used MC -->
                            <th>Exist</th> <!-- MG Target: Base -->
                            <th>Used</th> <!-- MG Target: Current -->
                            <th>Exist</th> <!-- Capacity(pcs): Base -->
                            <th>Used</th> <!-- Capacity(pcs): Current -->
                            <th>Exist</th> <!-- Capacity(kg): Base -->
                            <th>Used</th> <!-- Capacity(kg): Current -->
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($transferData as $t)
                            <tr>
                                <td class="fw-bold">{{ strip_tags($t->unit) }}</td>
                                <td>{{ $t->existing_mc }}</td> <!-- Machine: Exist -->
                                <td>{{ $t->used_mc }}</td> <!-- Machine: Used -->
                                <td style="font-size:6.5px; text-align:left;">{{ $t->transfer_in_details_pdf ?? '-' }}
                                </td>
                                <td style="font-size:6.5px; text-align:left;">{{ $t->transfer_out_details_pdf ?? '-' }}
                                </td>
                                <td>{{ $t->base_mg_target }}</td> <!-- MG Target: Exist -->
                                <td>{!! $t->current_mg_target !!}</td> <!-- MG Target: Used -->
                                <td>{{ $t->base_capacity_pieces }}</td> <!-- Capacity(pcs): Exist -->
                                <td>{!! $t->current_capacity_pieces !!}</td> <!-- Capacity(pcs): Used -->
                                <td>{{ $t->base_capacity_kg }}</td> <!-- Capacity(kg): Exist -->
                                <td>{!! $t->current_capacity_kg !!}</td> <!-- Capacity(kg): Used -->
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Total</th>
                            <td>{{ number_format($transferTotals['existing_mc']) }}</td> <!-- Machine: Exist -->
                            <td>{{ number_format($transferTotals['used_mc']) }}</td> <!-- Machine: Used -->
                            <td>-</td>
                            <td>-</td>
                            <td>-</td> <!-- MG Target: Exist (base) - no total shown -->
                            <td>{{ number_format($transferTotals['current_mg']) }}</td> <!-- MG Target: Used -->
                            <td>-</td> <!-- Capacity(pcs): Exist (base) - no total shown -->
                            <td>{{ number_format($transferTotals['current_pcs']) }}</td> <!-- Capacity(pcs): Used -->
                            <td>-</td> <!-- Capacity(kg): Exist (base) - no total shown -->
                            <td>{{ number_format($transferTotals['current_kg']) }}</td> <!-- Capacity(kg): Used -->
                        </tr>
                    </tfoot>
                </table>
            </td>

            <td width="50%" style="padding-left: 3px;">
                <span class="section-title" style="background-color: #93c8fdce; text-align: center;">Dryer Data</span>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Unit</th>
                            <th># Dryer</th>
                            <th>Avg<br>Batch</th>
                            <th>Avg<br>Time</th>
                            <th>Capacity</th>
                            <th>1st Wash</th>
                            <th>Cold</th>
                            <th>Mesurement<br>Corr</th>
                            <th>Final Wash</th>
                            <th>Deviation</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($dryerData as $d)
                            <tr>
                                <td>{{ $d->unit }}</td>
                                <td>{{ $d->num_dryer }}</td>
                                <td>{{ $d->avg_batch }}</td>
                                <td>{{ $d->avg_dryer_time }}</td>
                                <td>{{ $d->capacity }}</td>
                                <td>{{ $d->first_wash_dryer }}</td>
                                <td>{{ $d->cold_dryer }}</td>
                                <td>{{ $d->measurement_correction }}</td>
                                <td>{{ $d->final_wash_dryer }}</td>
                                <td>{!! $d->deviation !!}</td>
                                <td>{{ $d->total_dryer }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Total</th>
                            <td>{{ number_format($dryerTotals['num_dryer']) }}</td>
                            <td>-</td>
                            <td>-</td>
                            <td>-</td>
                            <td>{{ number_format($dryerTotals['first_wash']) }}</td>
                            <td>{{ number_format($dryerTotals['cold']) }}</td>
                            <td>{{ number_format($dryerTotals['meas']) }}</td>
                            <td>{{ number_format($dryerTotals['final_wash']) }}</td>
                            <td>{{ number_format($dryerTotals['deviation']) }}</td>
                            <td>{{ number_format($dryerTotals['total']) }}</td>
                        </tr>
                    </tfoot>
                </table>
            </td>
        </tr>
    </table>

    <!-- 4. CAPP Chart - Force on same page -->
    <div style="width: 100%; margin-top: 5px; text-align: center; page-break-inside: avoid; page-break-before: auto;">
        <span class="section-title"
            style="background-color: #93c8fd00; text-align: center; display: block; margin-bottom: 5px; padding: 2px;">

        </span>

        @if (isset($chartPath) && file_exists($chartPath))
            <div style="text-align: center; margin: 0 auto; width: 100%; page-break-inside: avoid;">
                <img src="{{ $chartPath }}" alt="CAPP Chart"
                    style="max-width: 100%; height: auto; max-height: 180px; width: auto; display: block; margin: 0 auto; border: 1px solid #ccc; image-rendering: auto;">
            </div>
        @else
            <table class="data-table"
                style="width: 70%; margin: 0 auto; border: 0.5px solid #999; page-break-inside: avoid;">
                <tr>
                    <td style="padding: 15px; text-align: center; color: #999;">
                        CAPP Data Unavailable
                    </td>
                </tr>
            </table>
        @endif
    </div>

    <div class="footer">
        Generated on {{ now()->format('d-M-Y H:i:s') }} | TUSUKA
    </div>
</body>

</html>