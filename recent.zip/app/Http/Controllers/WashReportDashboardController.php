<?php

namespace App\Http\Controllers;

use App\Models\Dryer;
use App\Models\DryProcessIE;
use App\Models\MachineTransfer;
use App\Models\SecondDryProcessEntry;
use App\Models\Unit;
use App\Models\WashReportEntry;
use App\Models\WashReportManPower;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Log;
use Yajra\DataTables\Facades\DataTables;
use Barryvdh\DomPDF\Facade\Pdf;

class WashReportDashboardController extends Controller
{
    public function index()
    {
        return view('backend.wash-report-dashboard.index');
    }

    /**
     * Get wash production data for a specific unit and date
     */
    private function getWashProductionDataForUnitAndDate($date, $unit)
    {
        try {
            $unitName = $unit->unitName;

            // Check if this is Unit 4 (Dyeing) or Unit 4 (Denim)
            $isUnit4Dyeing = str_contains($unitName, 'Unit 4 (Dyeing)') || str_contains($unitName, 'Unit 4 Dyeing');
            $isUnit4Denim = str_contains($unitName, 'Unit 4 (Denim)') || str_contains($unitName, 'Unit 4 Denim');

            // Determine the database unit name to search for
            if ($isUnit4Dyeing || $isUnit4Denim) {
                $dbUnitName = 'Unit 4';
            } else {
                $dbUnitName = $unitName;
            }

            // Query for both processes (315 and 316) to get received and delivery
            $query = "
            SELECT   
                p.ProcessName,
                WT.UD_WashType,         
                SUM(wop.Quantity) AS Quantity
            FROM [TusukaExtreme].[dbo].[MA_WorkOrderProduction] wop
            JOIN MA_WorkOrderItem woi ON wop.WorkOrderItemId = woi.RecId
            JOIN MA_Process p ON wop.ProcessId = p.RecId
            OUTER APPLY (
                SELECT DISTINCT KI.UD_WashType
                FROM TSK_WashWorkOrderItem TSK
                JOIN MA_WorkOrderItem KI ON KI.RecId = TSK.DocketWorkOrderItemId
                WHERE TSK.WashWorkOrderItemId = woi.RecId
            ) WT
            WHERE p.RecId IN (315, 316) 
            AND wop.ProductionDate = ?
            AND wop.UD_WashUnit = ?
            GROUP BY p.ProcessName, WT.UD_WashType
            ";

            $params = [$date, $dbUnitName];
            $sqlServerData = DB::connection('sqlsrv')->select($query, $params);

            $received = 0;
            $delivery = 0;

            foreach ($sqlServerData as $row) {
                $washType = $row->UD_WashType ?? null;
                $quantity = (int)($row->Quantity ?? 0);

                if ($isUnit4Dyeing) {
                    if ($washType === 'Over Dye') {
                        if ($row->ProcessName === 'Send from Wash') {
                            $received += $quantity;
                        } elseif ($row->ProcessName === 'Received from Sewing') {
                            $delivery += $quantity;
                        }
                    }
                } elseif ($isUnit4Denim) {
                    if ($washType !== 'Over Dye') {
                        if ($row->ProcessName === 'Send from Wash') {
                            $received += $quantity;
                        } elseif ($row->ProcessName === 'Received from Sewing') {
                            $delivery += $quantity;
                        }
                    }
                } else {
                    if ($row->ProcessName === 'Send from Wash') {
                        $received += $quantity;
                    } elseif ($row->ProcessName === 'Received from Sewing') {
                        $delivery += $quantity;
                    }
                }
            }

            // Separate query for Garment calculation - ONLY Process 316 (Received from Sewing)
            $garmentQuery = "
                SELECT   
                    SUM(wop.Quantity) AS TotalQuantity,
                    SUM(wop.Quantity * wo.UD_WeightOfPcsGmts) AS TotalWeight
                FROM [TusukaExtreme].[dbo].[MA_WorkOrderProduction] wop
                JOIN MA_WorkOrderItem woi ON wop.WorkOrderItemId = woi.RecId
                JOIN MA_WorkOrder wo ON woi.WorkOrderId = wo.RecId
                JOIN MA_Process p ON wop.ProcessId = p.RecId
                OUTER APPLY (
                    SELECT DISTINCT KI.UD_WashType
                    FROM TSK_WashWorkOrderItem TSK
                    JOIN MA_WorkOrderItem KI ON KI.RecId = TSK.DocketWorkOrderItemId
                    WHERE TSK.WashWorkOrderItemId = woi.RecId
                ) WT
                WHERE p.RecId = 316 
                AND wop.ProductionDate = ?
                AND wop.UD_WashUnit = ?
                ";

            $garmentParams = [$date, $dbUnitName];
            $garmentData = DB::connection('sqlsrv')->select($garmentQuery, $garmentParams);

            $garmentTotalQuantity = 0;
            $garmentTotalWeight = 0;

            if (!empty($garmentData)) {
                $garmentTotalQuantity = (int)($garmentData[0]->TotalQuantity ?? 0);
                $garmentTotalWeight = (float)($garmentData[0]->TotalWeight ?? 0);
            }

            // Calculate Garment ONLY from Process 316 (Received from Sewing)
            $garment = $garmentTotalQuantity > 0 ? $garmentTotalWeight / $garmentTotalQuantity : 0;

            return [
                'received' => $received,
                'delivery' => $delivery,
                'garment' => $garment,
                'garment_quantity' => $garmentTotalQuantity,
                'garment_weight' => $garmentTotalWeight
            ];
        } catch (\Exception $e) {
            \Log::error('SQL Server wash data error for ' . $unit->unitName . ' on ' . $date . ': ' . $e->getMessage());
            return [
                'received' => 0,
                'delivery' => 0,
                'garment' => 0,
                'garment_quantity' => 0,
                'garment_weight' => 0
            ];
        }
    }

    public function getUnitData(Request $request)
    {
        // Get date range from request
        $fromDate = $request->from_date;
        $toDate = $request->to_date;

        // If no dates provided, use default range (last 7 days)
        if (!$fromDate || !$toDate) {
            $toDate = now()->toDateString();
            $fromDate = now()->subDays(7)->toDateString();
        }

        // Get all units
        $units = Unit::all();

        // ========== REMOVE STATIC IN-HAND BALANCE ==========
        // We'll get in-hand balance from WashReportEntry table

        // FIRST: Calculate used machine counts from transfer data (same logic as getTransferData)
        $unitUsedMc = [];

        foreach ($units as $unit) {
            // Skip Unit 4 variants for now
            if ($unit->unitName == 'Unit 4 (Denim)' || $unit->unitName == 'Unit 4 (Dyeing)') {
                continue;
            }

            // Skip regular Unit 4 (we'll handle separately)
            if ($unit->unitName == 'Unit 4') {
                continue;
            }

            // Get transfers for this unit across the date range
            $transfersIn = MachineTransfer::with(['fromUnit', 'toUnit'])
                ->where('to_unit_id', $unit->id)
                ->whereBetween('transfer_date', [$fromDate, $toDate])
                ->get();

            $transfersOut = MachineTransfer::with(['fromUnit', 'toUnit'])
                ->where('from_unit_id', $unit->id)
                ->whereBetween('transfer_date', [$fromDate, $toDate])
                ->get();

            $transfersInCount = $transfersIn->sum('machine_count');
            $transfersOutCount = $transfersOut->sum('machine_count');

            // Get base machine count
            $baseMachineCount = $this->getBaseMachineCountForDate($unit->id, $toDate);

            // Calculate used machine count (base - total out + total in)
            $usedMachineCount = $baseMachineCount - $transfersOutCount + $transfersInCount;

            $unitUsedMc[$unit->unitName] = $usedMachineCount;
        }

        // Handle Unit 4 separately (combine Denim and Dyeing)
        $unit4Denim = Unit::where('unitName', 'Unit 4 (Denim)')->first();
        $unit4Dyeing = Unit::where('unitName', 'Unit 4 (Dyeing)')->first();

        $unit4UsedMc = 0;
        $unit4BaseMachineCount = 0;

        if ($unit4Denim) {
            $transfersIn = MachineTransfer::with(['fromUnit', 'toUnit'])
                ->where('to_unit_id', $unit4Denim->id)
                ->whereBetween('transfer_date', [$fromDate, $toDate])
                ->get();
            $transfersOut = MachineTransfer::with(['fromUnit', 'toUnit'])
                ->where('from_unit_id', $unit4Denim->id)
                ->whereBetween('transfer_date', [$fromDate, $toDate])
                ->get();
            $transfersInCount = $transfersIn->sum('machine_count');
            $transfersOutCount = $transfersOut->sum('machine_count');
            $baseMachineCount = (int)($unit4Denim->machineCount ?? 0);
            $unit4BaseMachineCount += $baseMachineCount;
            $unit4UsedMc += $baseMachineCount - $transfersOutCount + $transfersInCount;
        }

        if ($unit4Dyeing) {
            $transfersIn = MachineTransfer::with(['fromUnit', 'toUnit'])
                ->where('to_unit_id', $unit4Dyeing->id)
                ->whereBetween('transfer_date', [$fromDate, $toDate])
                ->get();
            $transfersOut = MachineTransfer::with(['fromUnit', 'toUnit'])
                ->where('from_unit_id', $unit4Dyeing->id)
                ->whereBetween('transfer_date', [$fromDate, $toDate])
                ->get();
            $transfersInCount = $transfersIn->sum('machine_count');
            $transfersOutCount = $transfersOut->sum('machine_count');
            $baseMachineCount = (int)($unit4Dyeing->machineCount ?? 0);
            $unit4BaseMachineCount += $baseMachineCount;
            $unit4UsedMc += $baseMachineCount - $transfersOutCount + $transfersInCount;
        }

        $unitUsedMc['Unit 4'] = $unit4UsedMc;

        // Prepare data array
        $unitData = [];

        // Process all regular units
        foreach ($units as $unit) {
            // Skip the Unit 4 variants - we'll handle them separately
            if ($unit->unitName == 'Unit 4 (Denim)' || $unit->unitName == 'Unit 4 (Dyeing)') {
                continue;
            }

            // For Unit 4, we'll handle it separately
            if ($unit->unitName == 'Unit 4') {
                continue;
            }

            // Cast unit values to proper types
            $machineCount = (int)($unit->machineCount ?? 0);
            $capacityKg = (float)($unit->capacity_kg ?? 0);
            $sewingLines = $unit->sewing_lines ?? '';

            // Get manpower data for this unit on the latest date
$manpowerDirect = 0;
$manpowerIndirect = 0;
$manpowerWorkHours = 0; // This will now be calculated from MachineStatus
$manpowerSmv = 0;

$manpower = WashReportManPower::where('unit', $unit->unitName)
    ->whereBetween('date', [$fromDate, $toDate])
    ->orderBy('date', 'desc')
    ->first();

if ($manpower) {
    $manpowerDirect = (int)($manpower->direct ?? 0);
    $manpowerIndirect = (int)($manpower->indirect ?? 0);
    $manpowerSmv = (float)($manpower->smv ?? 0);
}

// ===== NEW CODE: Calculate work hours from MachineStatus =====
// Get the latest machine status for this unit within the date range
$machineStatus = \App\Models\MachineStatus::where('unit', $unit->unitName)
    ->whereBetween('report_date', [$fromDate, $toDate])
    ->orderBy('report_date', 'desc')
    ->first();

if ($machineStatus) {
    // Convert up_duration and idle_duration to decimal hours
    $upHours = $this->convertTimeToDecimalHours($machineStatus->up_duration ?? '0:0:0');
    $idleHours = $this->convertTimeToDecimalHours($machineStatus->idle_duration ?? '0:0:0');
    
    // Get exist_mc (base machine count) - we need to fetch this from transfer data
    // We can get it from the unit's base machine count (existing_mc)
    $existMc = (int)($unit->machineCount ?? 0); // Default from unit model
    
    // If we have transfer data calculated earlier, we can get the existing_mc from there
    // But since we're in the loop, we need to calculate it similarly
    
    // Calculate working hours: {(up_duration + idle_duration) - 1} / exist_mc
    if ($existMc > 0) {
        $totalHours = $upHours + $idleHours;
        $manpowerWorkHours = ($totalHours - 1) / $existMc;
        
        // Ensure non-negative and reasonable value
        $manpowerWorkHours = max(0, $manpowerWorkHours);
    }
    
    \Log::info("Work hours calculation for {$unit->unitName}:", [
        'up_duration' => $machineStatus->up_duration,
        'up_hours' => $upHours,
        'idle_duration' => $machineStatus->idle_duration,
        'idle_hours' => $idleHours,
        'exist_mc' => $existMc,
        'calculated_work_hours' => $manpowerWorkHours
    ]);
} else {
    // Fallback to manpower table if no machine status found
    if ($manpower) {
        $manpowerWorkHours = (float)($manpower->work_hours ?? 0);
    }
}
// ===== END NEW CODE =====

            // Get WashReportEntry data for this unit across the date range
            $entryData = WashReportEntry::where('unit', $unit->unitName)
                ->whereBetween('date', [$fromDate, $toDate])
                ->get();

            $firstWashQty = $entryData->sum('FirstWashQty');
            $acidWashQty = $entryData->sum('AcidWashQty');
            $finalWashQty = $entryData->sum('FinalWashQty');
            $rewashQty = $entryData->sum('ReWashQty');
            $reworkDryProc = $entryData->sum('rework_dry_proc');

            // ========== GET IN-HAND BALANCE ==========
            // Get the latest in-hand balance for this unit within the date range
            $latestEntry = WashReportEntry::where('unit', $unit->unitName)
                ->whereBetween('date', [$fromDate, $toDate])
                ->whereNotNull('in_hand_balance')
                ->orderBy('date', 'desc')
                ->first();

            $inHandBalance = $latestEntry ? (int)($latestEntry->in_hand_balance ?? 0) : 0;

            // Collect remarks (non-empty ones)
            $remarks = $entryData->pluck('Remarks')->filter()->implode(' | ');

            // For production data, aggregate across ALL dates in the range
            $currentDate = Carbon::parse($fromDate);
            $endDate = Carbon::parse($toDate);

            $totalReceived = 0;
            $totalDelivery = 0;
            $totalGarmentQuantity = 0;
            $totalGarmentWeight = 0;

            while ($currentDate <= $endDate) {
                $dateStr = $currentDate->toDateString();
                $washData = $this->getWashProductionDataForUnitAndDate($dateStr, $unit);

                $totalReceived += (int)($washData['received'] ?? 0);
                $totalDelivery += (int)($washData['delivery'] ?? 0);
                $totalGarmentQuantity += (int)($washData['garment_quantity'] ?? 0);
                $totalGarmentWeight += (float)($washData['garment_weight'] ?? 0);

                $currentDate->addDay();
            }

            // Calculate garment for this unit
            $garment = $totalGarmentQuantity > 0 ? $totalGarmentWeight / $totalGarmentQuantity : 0;

            // Get used machine count from our calculated array
            $usedMc = $unitUsedMc[$unit->unitName] ?? $machineCount;

            // Calculate Forecast Target
            $forecastTarget = 0;

            if ($usedMc > 0 && $manpowerWorkHours > 0 && $garment > 0) {
                $forecastTarget = (($usedMc * 1000 * 0.6 / 23) * $manpowerWorkHours) / ($garment / 1000);
            }

            // Calculate Deviation (Forecast Target - Received)
            $deviation = $forecastTarget - $totalReceived;

            // Calculate Deviation %
            $deviationPercent = 0;
            if ($forecastTarget > 0) {
                $deviationPercent = ($deviation / $forecastTarget) * 100;
            }

            // Calculate 1st & 2nd Wash Ratio = final_wash_qty / first_wash_qty
            $washRatio = 0;
            if ($firstWashQty > 0) {
                $washRatio = $finalWashQty / $firstWashQty;
            }

            // Calculate Rewash % = rewash_qty / received
            $rewashPercent = 0;
            if ($totalReceived > 0) {
                $rewashPercent = ($rewashQty / $totalReceived) * 100;
            }

            $usedCapacityKg = 0;
            if ($machineCount > 0) {
                $usedCapacityKg = $capacityKg * ($usedMc / $machineCount);
            }

            $unitData[] = [
                'unit' => $unit->unitName,
                'machines' => $machineCount,
                'used_mc' => $usedMc,
                'capacity_kg' => $capacityKg,
                'used_capacity_kg' => $usedCapacityKg,
                'sewing_lines' => $sewingLines,
                'direct' => $manpowerDirect,
                'indirect' => $manpowerIndirect,
                'total' => $manpowerDirect + $manpowerIndirect,
                'work_hours' => round($manpowerWorkHours, 2),
                'smv' => $manpowerSmv,
                'received' => $totalReceived,
                'delivery' => $totalDelivery,
                'garment' => $garment,
                'first_wash_qty' => $firstWashQty,
                'acid_wash_qty' => $acidWashQty,
                'final_wash_qty' => $finalWashQty,
                'rewash_qty' => $rewashQty,
                'rework_dry_proc' => $reworkDryProc,
                'remarks' => $remarks ?: '-',
                'forecast_target' => $forecastTarget,
                'deviation' => $deviation,
                'deviation_percent' => $deviationPercent,
                'wash_ratio' => $washRatio,
                'rewash_percent' => $rewashPercent,
                'in_hand_balance' => $inHandBalance, // Now dynamic from WashReportEntry
            ];
        }

        // Now process Unit 4 - get data for "Unit 4" from the tables
        $unit4MachineCount = 0;
        $unit4CapacityKg = 0;
        $unit4SewingLines = [];

        // Get the Unit 4 (Denim) and Unit 4 (Dyeing) from units table for machine count and capacity
        $unit4Denim = Unit::where('unitName', 'Unit 4 (Denim)')->first();
        $unit4Dyeing = Unit::where('unitName', 'Unit 4 (Dyeing)')->first();

        if ($unit4Denim) {
            $unit4MachineCount += (int)($unit4Denim->machineCount ?? 0);
            $unit4CapacityKg += (float)($unit4Denim->capacity_kg ?? 0);
            if (!empty($unit4Denim->sewing_lines)) {
                $unit4SewingLines[] = $unit4Denim->sewing_lines;
            }
        }

        if ($unit4Dyeing) {
            $unit4MachineCount += (int)($unit4Dyeing->machineCount ?? 0);
            $unit4CapacityKg += (float)($unit4Dyeing->capacity_kg ?? 0);
            if (!empty($unit4Dyeing->sewing_lines)) {
                $unit4SewingLines[] = $unit4Dyeing->sewing_lines;
            }
        }

        // Get manpower data for Unit 4 (from washreportmanpower where unit = 'Unit 4')
$manpowerDirect = 0;
$manpowerIndirect = 0;
$manpowerWorkHours = 0;
$manpowerSmv = 0;

$manpower = WashReportManPower::where('unit', 'Unit 4')
    ->whereBetween('date', [$fromDate, $toDate])
    ->orderBy('date', 'desc')
    ->first();

if ($manpower) {
    $manpowerDirect = (int)($manpower->direct ?? 0);
    $manpowerIndirect = (int)($manpower->indirect ?? 0);
    $manpowerSmv = (float)($manpower->smv ?? 0);
}

// ===== NEW CODE: Calculate work hours from MachineStatus for Unit 4 =====
$machineStatus = \App\Models\MachineStatus::where('unit', 'Unit 4')
    ->whereBetween('report_date', [$fromDate, $toDate])
    ->orderBy('report_date', 'desc')
    ->first();

if ($machineStatus) {
    // Convert up_duration and idle_duration to decimal hours
    $upHours = $this->convertTimeToDecimalHours($machineStatus->up_duration ?? '0:0:0');
    $idleHours = $this->convertTimeToDecimalHours($machineStatus->idle_duration ?? '0:0:0');
    
    // Get exist_mc for Unit 4 (combined from Denim and Dyeing)
    $existMc = $unit4MachineCount; // We already calculated this earlier
    
    // Calculate working hours: {(up_duration + idle_duration) - 1} / exist_mc
    if ($existMc > 0) {
        $totalHours = $upHours + $idleHours;
        $manpowerWorkHours = ($totalHours - 1) / $existMc;
        
        // Ensure non-negative and reasonable value
        $manpowerWorkHours = max(0, $manpowerWorkHours);
    }
    
    \Log::info("Work hours calculation for Unit 4:", [
        'up_duration' => $machineStatus->up_duration,
        'up_hours' => $upHours,
        'idle_duration' => $machineStatus->idle_duration,
        'idle_hours' => $idleHours,
        'exist_mc' => $existMc,
        'calculated_work_hours' => $manpowerWorkHours
    ]);
} else {
    // Fallback to manpower table if no machine status found
    if ($manpower) {
        $manpowerWorkHours = (float)($manpower->work_hours ?? 0);
    }
}
// ===== END NEW CODE =====

        // Get WashReportEntry data for Unit 4
        $entryData = WashReportEntry::where('unit', 'Unit 4')
            ->whereBetween('date', [$fromDate, $toDate])
            ->get();

        $firstWashQty = $entryData->sum('FirstWashQty');
        $acidWashQty = $entryData->sum('AcidWashQty');
        $finalWashQty = $entryData->sum('FinalWashQty');
        $rewashQty = $entryData->sum('ReWashQty');
        $reworkDryProc = $entryData->sum('rework_dry_proc');
        $remarks = $entryData->pluck('Remarks')->filter()->implode(' | ');

        // ========== GET IN-HAND BALANCE FOR UNIT 4 ==========
        $latestUnit4Entry = WashReportEntry::where('unit', 'Unit 4')
            ->whereBetween('date', [$fromDate, $toDate])
            ->whereNotNull('in_hand_balance')
            ->orderBy('date', 'desc')
            ->first();

        $unit4InHandBalance = $latestUnit4Entry ? (int)($latestUnit4Entry->in_hand_balance ?? 0) : 0;

        // For production data for Unit 4, we need to get data for both variants
        $totalReceived = 0;
        $totalDelivery = 0;
        $totalGarmentQuantity = 0;
        $totalGarmentWeight = 0;

        // Create temp unit objects for the variants
        $denimUnit = new \stdClass();
        $denimUnit->unitName = 'Unit 4 (Denim)';

        $dyeingUnit = new \stdClass();
        $dyeingUnit->unitName = 'Unit 4 (Dyeing)';

        $currentDate = Carbon::parse($fromDate);
        $endDate = Carbon::parse($toDate);

        while ($currentDate <= $endDate) {
            $dateStr = $currentDate->toDateString();

            // Get data for Denim variant
            $washDataDenim = $this->getWashProductionDataForUnitAndDate($dateStr, $denimUnit);

            // Get data for Dyeing variant
            $washDataDyeing = $this->getWashProductionDataForUnitAndDate($dateStr, $dyeingUnit);

            $totalReceived += (int)($washDataDenim['received'] ?? 0) + (int)($washDataDyeing['received'] ?? 0);
            $totalDelivery += (int)($washDataDenim['delivery'] ?? 0) + (int)($washDataDyeing['delivery'] ?? 0);
            $totalGarmentQuantity += (int)($washDataDenim['garment_quantity'] ?? 0) + (int)($washDataDyeing['garment_quantity'] ?? 0);
            $totalGarmentWeight += (float)($washDataDenim['garment_weight'] ?? 0) + (float)($washDataDyeing['garment_weight'] ?? 0);
            $currentDate->addDay();
        }

        // Calculate garment for Unit 4
        $garment = $totalGarmentQuantity > 0 ? $totalGarmentWeight / $totalGarmentQuantity : 0;

        // Get used machine count for Unit 4 from our calculated array
        $usedMc = $unitUsedMc['Unit 4'] ?? $unit4MachineCount;

        // Calculate Forecast Target for Unit 4
        $forecastTarget = 0;

        if ($usedMc > 0 && $manpowerWorkHours > 0 && $garment > 0) {
            $forecastTarget = (($usedMc * 1000 * 0.6 / 23) * $manpowerWorkHours) / ($garment / 1000);
        }

        // Calculate Deviation (Forecast Target - Received)
        $deviation = $forecastTarget - $totalReceived;

        // Calculate Deviation %
        $deviationPercent = 0;
        if ($forecastTarget > 0) {
            $deviationPercent = ($deviation / $forecastTarget) * 100;
        }

        // Calculate 1st & 2nd Wash Ratio = final_wash_qty / first_wash_qty
        $washRatio = 0;
        if ($firstWashQty > 0) {
            $washRatio = $finalWashQty / $firstWashQty;
        }

        // Calculate Rewash % = rewash_qty / received
        $rewashPercent = 0;
        if ($totalReceived > 0) {
            $rewashPercent = ($rewashQty / $totalReceived) * 100;
        }

        $usedCapacityKg = 0;
        if ($unit4MachineCount > 0) {
            $usedCapacityKg = $unit4CapacityKg * ($usedMc / $unit4MachineCount);
        }

        // Create combined Unit 4 entry
        $unit4Combined = [
            'unit' => 'Unit 4',
            'machines' => $unit4MachineCount,
            'used_mc' => $usedMc,
            'capacity_kg' => $unit4CapacityKg,
            'used_capacity_kg' => $usedCapacityKg,
            'sewing_lines' => !empty($unit4SewingLines) ? implode(' + ', $unit4SewingLines) : '-',
            'direct' => $manpowerDirect,
            'indirect' => $manpowerIndirect,
            'total' => $manpowerDirect + $manpowerIndirect,
            'work_hours' => round($manpowerWorkHours, 2),
            'smv' => $manpowerSmv,
            'received' => $totalReceived,
            'delivery' => $totalDelivery,
            'garment' => $garment,
            'first_wash_qty' => $firstWashQty,
            'acid_wash_qty' => $acidWashQty,
            'final_wash_qty' => $finalWashQty,
            'rewash_qty' => $rewashQty,
            'rework_dry_proc' => $reworkDryProc,
            'remarks' => $remarks ?: '-',
            'forecast_target' => $forecastTarget,
            'deviation' => $deviation,
            'deviation_percent' => $deviationPercent,
            'wash_ratio' => $washRatio,
            'rewash_percent' => $rewashPercent,
            'in_hand_balance' => $unit4InHandBalance, // Now dynamic from WashReportEntry
        ];

        // Add Unit 4 to the data array
        $unitData[] = $unit4Combined;

        // Sort units by name
        $order = ['Unit 1', 'Unit 2', 'Unit 3', 'Unit 4', 'Unit 5', 'Unit TWL'];
        usort($unitData, function ($a, $b) use ($order) {
            $posA = array_search($a['unit'], $order);
            $posB = array_search($b['unit'], $order);
            if ($posA === false) $posA = 999;
            if ($posB === false) $posB = 999;
            return $posA - $posB;
        });

        $formattedFromDate = Carbon::parse($fromDate)->format('d-m-Y');
        $formattedToDate = Carbon::parse($toDate)->format('d-m-Y');
        $dateRange = $formattedFromDate . ' to ' . $formattedToDate;

        return DataTables::of($unitData)
            ->with('date_range', $dateRange)
            ->editColumn('capacity_kg', function ($row) {
                return (float)($row['capacity_kg'] ?? 0);
            })
            ->editColumn('sewing_lines', function ($row) {
                return $row['sewing_lines'] ?? '-';
            })
            ->editColumn('direct', function ($row) {
                return (int)($row['direct'] ?? 0);
            })
            ->editColumn('indirect', function ($row) {
                return (int)($row['indirect'] ?? 0);
            })
            ->editColumn('total', function ($row) {
                return (int)($row['total'] ?? 0);
            })
            ->editColumn('work_hours', function ($row) {
                return (float)($row['work_hours'] ?? 0);
            })
            ->editColumn('smv', function ($row) {
                return (float)($row['smv'] ?? 0);
            })
            ->editColumn('received', function ($row) {
                $value = (int)($row['received'] ?? 0);
                return number_format($value);
            })
            ->editColumn('delivery', function ($row) {
                $value = (int)($row['delivery'] ?? 0);
                return number_format($value);
            })
            ->editColumn('garment', function ($row) {
                if (isset($row['garment']) && $row['garment'] > 0) {
                    return round((float)$row['garment']);
                }
                return 0;
            })
            ->editColumn('first_wash_qty', function ($row) {
                $value = (int)($row['first_wash_qty'] ?? 0);
                return number_format($value);
            })
            ->editColumn('acid_wash_qty', function ($row) {
                $value = (int)($row['acid_wash_qty'] ?? 0);
                return number_format($value);
            })
            ->editColumn('final_wash_qty', function ($row) {
                $value = (int)($row['final_wash_qty'] ?? 0);
                return number_format($value);
            })
            ->editColumn('rewash_qty', function ($row) {
                $value = (int)($row['rewash_qty'] ?? 0);
                return number_format($value);
            })
            ->editColumn('rework_dry_proc', function ($row) {
                $value = (int)($row['rework_dry_proc'] ?? 0);
                return number_format($value);
            })
            ->editColumn('forecast_target', function ($row) {
                return number_format(round($row['forecast_target'] ?? 0));
            })
            ->editColumn('deviation', function ($row) {
                $deviation = round($row['deviation'] ?? 0);
                $class = $deviation > 0 ? 'text-danger' : ($deviation < 0 ? 'text-success' : '');
                return '<span class="' . $class . ' fw-bold">' . number_format($deviation, 0) . '</span>';
            })
            ->editColumn('deviation_percent', function ($row) {
                $deviationPercent = (float)($row['deviation_percent'] ?? 0);
                $class = $deviationPercent > 0 ? 'text-danger' : ($deviationPercent < 0 ? 'text-success' : '');
                return '<span class="' . $class . ' fw-bold">' . number_format($deviationPercent, 2) . '%</span>';
            })
            ->editColumn('wash_ratio', function ($row) {
                $washRatio = (float)($row['wash_ratio'] ?? 0);
                return number_format($washRatio * 100, 2) . '%';
            })
            ->editColumn('rewash_percent', function ($row) {
                return number_format((float)($row['rewash_percent'] ?? 0)) . '%';
            })
            ->editColumn('in_hand_balance', function ($row) {
                // Format the in-hand balance with commas - now dynamic
                return number_format((int)($row['in_hand_balance'] ?? 0));
            })
            ->rawColumns(['deviation', 'deviation_percent'])
            ->make(true);
    }

    /**
     * Get 1st Dry Process data
     */

    public function getFirstDryProcessData(Request $request)
    {
        $fromDate = $request->from_date;
        $toDate = $request->to_date;

        if (!$fromDate || !$toDate) {
            $toDate = now()->toDateString();
            $fromDate = now()->subDays(7)->toDateString();
        }

        try {
            // ========== PART 1: GET TPL DATA FROM QC DATABASE ==========
            $query = "
            SELECT
                fc.PlantName,
                fc.UnitName,
                wp.ProcessName,
                SUM(fc.ProductionQty) AS ProductionQty,
                SUM(fc.DefectQty) AS DefectQty,
                SUM(ISNULL(t.DayTarget, 0)) AS TargetQty
            FROM
            (
                SELECT 
                    p.PlantName,
                    pu.UnitName,
                    fq.QcDate,
                    fq.WashProcessId,
                    SUM(CASE WHEN fq.QcStatusId IN (1,3) THEN 1 ELSE 0 END) AS ProductionQty,
                    SUM(CASE WHEN fq.QcStatusId = 2 THEN 1 ELSE 0 END) AS DefectQty
                FROM [DHU_WashDB].[dbo].[FirstDryProcessQc] fq
                JOIN FirstDryProcess fp ON fq.FirstDryProcessId = fp.Id
                JOIN PlantUnit pu ON fp.UnitId = pu.id
                JOIN Plant p ON pu.PlantId = p.Id
                WHERE fq.IsDeleted = 0
                AND fq.QcDate BETWEEN ? AND ?
                GROUP BY 
                    p.PlantName,
                    pu.UnitName,
                    fq.QcDate,
                    fq.WashProcessId
            ) fc
            LEFT JOIN
            (
                SELECT 
                    wh.WorkingHourDay AS [Date],
                    whdpm.WashProcessId,
                    SUM(whdpm.DailyTarget) AS DayTarget
                FROM WorkingHourDetailManPower whdpm
                JOIN WorkingHourDetail whd ON whdpm.WorkingHourDetailId = whd.Id
                JOIN WorkingHour wh ON whd.WorkingHourId = wh.Id
                WHERE wh.WorkingHourDay BETWEEN ? AND ?
                GROUP BY 
                    wh.WorkingHourDay,
                    whdpm.WashProcessId
            ) t
                ON t.WashProcessId = fc.WashProcessId
                AND t.[Date] = fc.QcDate
            JOIN WashProcess wp 
                ON wp.Id = fc.WashProcessId
            WHERE wp.ProcessName IN ('Whisker', 'Handbrush', 'First Dry Final')
            GROUP BY fc.PlantName, fc.UnitName, wp.ProcessName
            ORDER BY fc.PlantName, wp.ProcessName;
        ";

            $params = [$fromDate, $toDate, $fromDate, $toDate];
            $results = DB::connection('sqlsrv_second')->select($query, $params);

            // ========== PART 2: GET TWL DATA FROM SecondDryProcessEntry ==========
            // Get Whisker data for TWL (no defect tracking)
            $whiskerData = SecondDryProcessEntry::select(
                DB::raw("'TWL' as PlantName"),
                DB::raw("'Whisker' as ProcessName"),
                DB::raw('SUM(TargetQty) as TargetQty'),
                DB::raw('SUM(ProductionQty) as ProductionQty'),
                DB::raw('0 as DefectQty') // Whisker doesn't have defect tracking
            )
                ->where('plant', 'TWL')
                ->where('processType', 'Whisker')
                ->whereBetween('date', [$fromDate, $toDate])
                ->groupBy('plant')
                ->get();

            // Get Hand Brush data for TWL (no defect tracking)
            $handBrushData = SecondDryProcessEntry::select(
                DB::raw("'TWL' as PlantName"),
                DB::raw("'Handbrush' as ProcessName"),
                DB::raw('SUM(TargetQty) as TargetQty'),
                DB::raw('SUM(ProductionQty) as ProductionQty'),
                DB::raw('0 as DefectQty') // Hand Brush doesn't have defect tracking
            )
                ->where('plant', 'TWL')
                ->where('processType', 'Hand Brush')
                ->whereBetween('date', [$fromDate, $toDate])
                ->groupBy('plant')
                ->get();

            // Get 1st Dry Final data for TWL (WITH defect tracking)
            $firstDryFinalData = SecondDryProcessEntry::select(
                DB::raw("'TWL' as PlantName"),
                DB::raw("'First Dry Final' as ProcessName"),
                DB::raw('SUM(TargetQty) as TargetQty'),
                DB::raw('SUM(ProductionQty) as ProductionQty'),
                DB::raw('SUM(defectQty) as DefectQty') // Now including defectQty
            )
                ->where('plant', 'TWL')
                ->where('processType', '1st Dry Final')
                ->whereBetween('date', [$fromDate, $toDate])
                ->groupBy('plant')
                ->get();

            // ========== PART 3: MERGE THE DATA ==========
            // Start with QC results (TPL data)
            $mergedResults = collect($results);

            // Add TWL data from SecondDryProcessEntry
            foreach ($whiskerData as $item) {
                $mergedResults->push((object)[
                    'PlantName' => 'TWL',
                    'UnitName' => null,
                    'ProcessName' => 'Whisker',
                    'ProductionQty' => $item->ProductionQty,
                    'DefectQty' => $item->DefectQty, // Now 0
                    'TargetQty' => $item->TargetQty
                ]);
            }

            foreach ($handBrushData as $item) {
                $mergedResults->push((object)[
                    'PlantName' => 'TWL',
                    'UnitName' => null,
                    'ProcessName' => 'Handbrush',
                    'ProductionQty' => $item->ProductionQty,
                    'DefectQty' => $item->DefectQty, // Now 0
                    'TargetQty' => $item->TargetQty
                ]);
            }

            foreach ($firstDryFinalData as $item) {
                $mergedResults->push((object)[
                    'PlantName' => 'TWL',
                    'UnitName' => null,
                    'ProcessName' => 'First Dry Final',
                    'ProductionQty' => $item->ProductionQty,
                    'DefectQty' => $item->DefectQty, // Now includes defectQty from SecondDryProcessEntry
                    'TargetQty' => $item->TargetQty
                ]);
            }

            // Get IE data aggregated for the date range
            $ieData = DryProcessIE::select(
                'plant',
                DB::raw('AVG(manPower) as avg_manPower'),
                DB::raw('AVG(workingHr) as avg_workingHr'),
                DB::raw('AVG(smv) as avg_smv')
            )
                ->where('processType', '1st Dry Process')
                ->whereBetween('date', [$fromDate, $toDate])
                ->whereIn('plant', ['TPL', 'TWL'])
                ->groupBy('plant')
                ->get()
                ->keyBy('plant');

            // Transform data to the required format (group by plant only)
            $groupedData = [];
            foreach ($mergedResults as $row) {
                $plant = $row->PlantName;
                $key = $plant;

                if (!isset($groupedData[$key])) {
                    $groupedData[$key] = [
                        'plant' => $plant,
                        'whisker_target' => 0,
                        'whisker_production' => 0,
                        'whisker_defect' => 0,
                        'handbrush_target' => 0,
                        'handbrush_production' => 0,
                        'handbrush_defect' => 0,
                        'firstdryfinal_target' => 0,
                        'firstdryfinal_production' => 0,
                        'firstdryfinal_defect' => 0,
                        'firstdryfinal_deviation' => 0,
                        'total_defect_qty' => 0,
                        'manPower' => 0,
                        'workingHr' => 0,
                        'smv' => 0
                    ];
                }

                // Fill data based on process name
                switch ($row->ProcessName) {
                    case 'Whisker':
                        $groupedData[$key]['whisker_target'] += (int)$row->TargetQty;
                        $groupedData[$key]['whisker_production'] += (int)$row->ProductionQty;
                        $groupedData[$key]['whisker_defect'] += (int)($row->DefectQty ?? 0);
                        $groupedData[$key]['total_defect_qty'] += (int)($row->DefectQty ?? 0);
                        break;
                    case 'Handbrush':
                        $groupedData[$key]['handbrush_target'] += (int)$row->TargetQty;
                        $groupedData[$key]['handbrush_production'] += (int)$row->ProductionQty;
                        $groupedData[$key]['handbrush_defect'] += (int)($row->DefectQty ?? 0);
                        $groupedData[$key]['total_defect_qty'] += (int)($row->DefectQty ?? 0);
                        break;
                    case 'First Dry Final':
                        $groupedData[$key]['firstdryfinal_target'] += (int)$row->TargetQty;
                        $groupedData[$key]['firstdryfinal_production'] += (int)$row->ProductionQty;
                        $groupedData[$key]['firstdryfinal_defect'] += (int)($row->DefectQty ?? 0);
                        $groupedData[$key]['firstdryfinal_deviation'] += (int)$row->TargetQty - (int)$row->ProductionQty;
                        $groupedData[$key]['total_defect_qty'] += (int)($row->DefectQty ?? 0);
                        break;
                }
            }

            // Merge IE data with production data (use averages for IE data)
            $finalData = [];
            foreach ($groupedData as $key => $data) {
                if (isset($ieData[$data['plant']])) {
                    $data['manPower'] = round($ieData[$data['plant']]->avg_manPower ?? 0);
                    $data['workingHr'] = round($ieData[$data['plant']]->avg_workingHr ?? 0, 2);
                    $data['smv'] = round($ieData[$data['plant']]->avg_smv ?? 0, 2);
                }

                $finalData[] = $data;
            }

            // Also add any IE data that doesn't have matching production data
            foreach ($ieData as $plant => $ie) {
                if (!isset($groupedData[$plant])) {
                    $finalData[] = [
                        'plant' => $plant,
                        'whisker_target' => 0,
                        'whisker_production' => 0,
                        'whisker_defect' => 0,
                        'handbrush_target' => 0,
                        'handbrush_production' => 0,
                        'handbrush_defect' => 0,
                        'firstdryfinal_target' => 0,
                        'firstdryfinal_production' => 0,
                        'firstdryfinal_defect' => 0,
                        'firstdryfinal_deviation' => 0,
                        'total_defect_qty' => 0,
                        'manPower' => round($ie->avg_manPower ?? 0),
                        'workingHr' => round($ie->avg_workingHr ?? 0, 2),
                        'smv' => round($ie->avg_smv ?? 0, 2)
                    ];
                }
            }

            // Sort by plant
            usort($finalData, function ($a, $b) {
                return strcmp($a['plant'], $b['plant']);
            });

            return DataTables::of($finalData)
                ->editColumn('plant', function ($row) {
                    return $row['plant'] ?? '-';
                })
                ->editColumn('whisker_target', function ($row) {
                    return number_format((int)($row['whisker_target'] ?? 0));
                })
                ->editColumn('whisker_production', function ($row) {
                    return number_format((int)($row['whisker_production'] ?? 0));
                })
                ->editColumn('handbrush_target', function ($row) {
                    return number_format((int)($row['handbrush_target'] ?? 0));
                })
                ->editColumn('handbrush_production', function ($row) {
                    return number_format((int)($row['handbrush_production'] ?? 0));
                })
                ->editColumn('firstdryfinal_target', function ($row) {
                    return number_format((int)($row['firstdryfinal_target'] ?? 0));
                })
                ->editColumn('firstdryfinal_production', function ($row) {
                    return number_format((int)($row['firstdryfinal_production'] ?? 0));
                })
                ->editColumn('deviation', function ($row) {
                    $deviation = (int)($row['firstdryfinal_deviation'] ?? 0);
                    $class = $deviation > 0 ? 'text-danger' : ($deviation < 0 ? 'text-success' : '');
                    return '<span class="' . $class . ' fw-bold">' . number_format($deviation) . '</span>';
                })
                ->editColumn('defect_qty', function ($row) {
                    return number_format((int)($row['total_defect_qty'] ?? 0));
                })
                ->editColumn('manPower', function ($row) {
                    return number_format((int)($row['manPower'] ?? 0));
                })
                ->editColumn('workingHr', function ($row) {
                    return number_format((float)($row['workingHr'] ?? 0), 2);
                })
                ->editColumn('smv', function ($row) {
                    return number_format((float)($row['smv'] ?? 0), 2);
                })
                ->rawColumns(['deviation'])
                ->make(true);
        } catch (\Exception $e) {
            \Log::error('Error in getFirstDryProcessData: ' . $e->getMessage());
            \Log::error('Stack trace: ' . $e->getTraceAsString());
            return DataTables::of([])->make(true);
        }
    }

    public function getSecondDryProcessData(Request $request)
    {
        $fromDate = $request->from_date;
        $toDate = $request->to_date;

        if (!$fromDate || !$toDate) {
            $toDate = now()->toDateString();
            $fromDate = now()->subDays(7)->toDateString();
        }

        try {
            // ========== PART 1: GET LASER & PP SPRAY DATA (BOTH PLANTS) ==========
            // Get aggregated Laser production data from SecondDryProcessEntry
            $laserData = SecondDryProcessEntry::select(
                'plant',
                DB::raw('SUM(TargetQty) as total_target'),
                DB::raw('SUM(ProductionQty) as total_production'),
                DB::raw('SUM(defectQty) as total_defect') // Include defect for Laser if needed
            )
                ->where('processType', 'Laser')
                ->whereBetween('date', [$fromDate, $toDate])
                ->groupBy('plant')
                ->get()
                ->keyBy('plant');

            // Get aggregated PP Spray production data from SecondDryProcessEntry
            $ppSprayData = SecondDryProcessEntry::select(
                'plant',
                DB::raw('SUM(TargetQty) as total_target'),
                DB::raw('SUM(ProductionQty) as total_production'),
                DB::raw('SUM(defectQty) as total_defect') // Include defect for PP Spray if needed
            )
                ->where('processType', 'PP Spray')
                ->whereBetween('date', [$fromDate, $toDate])
                ->groupBy('plant')
                ->get()
                ->keyBy('plant');

            // ========== PART 2: GET 2ND DRY FINAL DATA ==========
            // Get TPL 2nd Dry Final data from QC database
            $query = "
            SELECT
                fc.PlantName,
                SUM(fc.ProductionQty) AS ProductionQty,
                SUM(fc.DefectQty) AS DefectQty,
                SUM(ISNULL(t.DailyTarget, 0)) AS TargetQty
            FROM
            (
                SELECT 
                    p.PlantName,
                    pu.UnitName,
                    fq.QcDate,
                    fq.WashProcessId,
                    SUM(CASE WHEN fq.QcStatusId IN (1,3) THEN 1 ELSE 0 END) AS ProductionQty,
                    SUM(CASE WHEN fq.QcStatusId = 2 THEN 1 ELSE 0 END) AS DefectQty
                FROM [DHU_WashDB].[dbo].[FirstDryProcessQc] fq
                JOIN FirstDryProcess fp ON fq.FirstDryProcessId = fp.Id
                JOIN PlantUnit pu ON fp.UnitId = pu.id
                JOIN Plant p ON pu.PlantId = p.Id
                WHERE fq.IsDeleted = 0
                  AND fq.QcDate BETWEEN ? AND ?
                GROUP BY 
                    p.PlantName,
                    pu.UnitName,
                    fq.QcDate,
                    fq.WashProcessId
            ) fc
            LEFT JOIN
            (
                SELECT 
                    wh.WorkingHourDay AS [Date],
                    whdpm.WashProcessId,
                    SUM(whdpm.DailyTarget) AS DailyTarget
                FROM WorkingHourDetailManPower whdpm
                JOIN WorkingHourDetail whd ON whdpm.WorkingHourDetailId = whd.Id
                JOIN WorkingHour wh ON whd.WorkingHourId = wh.Id
                WHERE wh.WorkingHourDay BETWEEN ? AND ?
                GROUP BY 
                    wh.WorkingHourDay,
                    whdpm.WashProcessId
            ) t
                ON t.WashProcessId = fc.WashProcessId
                AND t.[Date] = fc.QcDate
            JOIN WashProcess wp 
                ON wp.Id = fc.WashProcessId
            WHERE wp.ProcessName = '2nd Dry Final'
            GROUP BY fc.PlantName
            ORDER BY fc.PlantName;
        ";

            $params = [$fromDate, $toDate, $fromDate, $toDate];
            $secondDryFinalResults = DB::connection('sqlsrv_second')->select($query, $params);

            // ========== PART 3: GET TWL 2ND DRY FINAL DATA FROM SecondDryProcessEntry ==========
            $twlSecondDryFinalData = SecondDryProcessEntry::select(
                DB::raw("'TWL' as PlantName"),
                DB::raw('SUM(TargetQty) as TargetQty'),
                DB::raw('SUM(ProductionQty) as ProductionQty'),
                DB::raw('SUM(defectQty) as DefectQty') // Now including defectQty
            )
                ->where('plant', 'TWL')
                ->where('processType', '2nd Dry Final')
                ->whereBetween('date', [$fromDate, $toDate])
                ->groupBy('plant')
                ->first();

            // Get all unique plants
            $allPlants = array_unique(array_merge(
                $laserData->keys()->toArray(),
                $ppSprayData->keys()->toArray(),
                array_column($secondDryFinalResults, 'PlantName')
            ));

            // Make sure TWL is included
            if (!in_array('TWL', $allPlants)) {
                $allPlants[] = 'TWL';
            }

            // Create combined data array using plant as key
            $combinedData = [];

            // Initialize all plants
            foreach ($allPlants as $plant) {
                $combinedData[$plant] = [
                    'plant' => $plant,
                    'laser_target' => 0,
                    'laser_production' => 0,
                    'laser_defect' => 0,
                    'ppspray_target' => 0,
                    'ppspray_production' => 0,
                    'ppspray_defect' => 0,
                    'seconddryfinal_target' => 0,
                    'seconddryfinal_production' => 0,
                    'seconddryfinal_defect' => 0,
                    'seconddryfinal_deviation' => 0,
                    'total_defect_qty' => 0,
                    'manPower' => 0,
                    'workingHr' => 0,
                    'smv' => 0,
                ];
            }

            // Add Laser data (aggregated)
            foreach ($laserData as $plant => $item) {
                if (isset($combinedData[$plant])) {
                    $combinedData[$plant]['laser_target'] = (int)$item->total_target;
                    $combinedData[$plant]['laser_production'] = (int)$item->total_production;
                    $combinedData[$plant]['laser_defect'] = (int)($item->total_defect ?? 0);
                    $combinedData[$plant]['total_defect_qty'] += (int)($item->total_defect ?? 0);
                }
            }

            // Add PP Spray data (aggregated)
            foreach ($ppSprayData as $plant => $item) {
                if (isset($combinedData[$plant])) {
                    $combinedData[$plant]['ppspray_target'] = (int)$item->total_target;
                    $combinedData[$plant]['ppspray_production'] = (int)$item->total_production;
                    $combinedData[$plant]['ppspray_defect'] = (int)($item->total_defect ?? 0);
                    $combinedData[$plant]['total_defect_qty'] += (int)($item->total_defect ?? 0);
                }
            }

            // Add 2nd Dry Final data from QC database (for TPL and any other plants except TWL)
            foreach ($secondDryFinalResults as $row) {
                $plant = $row->PlantName;

                // Skip TWL - we'll handle it separately
                if ($plant == 'TWL') {
                    continue;
                }

                if (isset($combinedData[$plant])) {
                    $combinedData[$plant]['seconddryfinal_target'] = (int)$row->TargetQty;
                    $combinedData[$plant]['seconddryfinal_production'] = (int)$row->ProductionQty;
                    $combinedData[$plant]['seconddryfinal_defect'] = (int)($row->DefectQty ?? 0);
                    $combinedData[$plant]['seconddryfinal_deviation'] = (int)$row->TargetQty - (int)$row->ProductionQty;
                    $combinedData[$plant]['total_defect_qty'] += (int)($row->DefectQty ?? 0);
                }
            }

            // Add TWL 2nd Dry Final data from SecondDryProcessEntry (WITH defect)
            if ($twlSecondDryFinalData && isset($combinedData['TWL'])) {
                $combinedData['TWL']['seconddryfinal_target'] = (int)$twlSecondDryFinalData->TargetQty;
                $combinedData['TWL']['seconddryfinal_production'] = (int)$twlSecondDryFinalData->ProductionQty;
                $combinedData['TWL']['seconddryfinal_defect'] = (int)($twlSecondDryFinalData->DefectQty ?? 0);
                $combinedData['TWL']['seconddryfinal_deviation'] = (int)$twlSecondDryFinalData->TargetQty - (int)$twlSecondDryFinalData->ProductionQty;
                $combinedData['TWL']['total_defect_qty'] += (int)($twlSecondDryFinalData->DefectQty ?? 0);
            }

            // Get aggregated IE data for each plant (averages)
            foreach ($combinedData as $plant => &$data) {
                $ieData = DryProcessIE::select(
                    DB::raw('AVG(manPower) as avg_manPower'),
                    DB::raw('AVG(workingHr) as avg_workingHr'),
                    DB::raw('AVG(smv) as avg_smv')
                )
                    ->where('plant', $plant)
                    ->whereBetween('date', [$fromDate, $toDate])
                    ->where('processType', '2nd Dry Process')
                    ->first();

                $data['manPower'] = round($ieData->avg_manPower ?? 0);
                $data['workingHr'] = round($ieData->avg_workingHr ?? 0, 2);
                $data['smv'] = round($ieData->avg_smv ?? 0, 2);
            }

            // Convert to collection and sort by plant
            $sortedData = collect($combinedData)->sortBy('plant')->values();

            return DataTables::of($sortedData)
                ->editColumn('plant', function ($row) {
                    return $row['plant'] ?? '-';
                })
                ->editColumn('laser_target', function ($row) {
                    return number_format((int)($row['laser_target'] ?? 0));
                })
                ->editColumn('laser_production', function ($row) {
                    return number_format((int)($row['laser_production'] ?? 0));
                })
                ->editColumn('ppspray_target', function ($row) {
                    return number_format((int)($row['ppspray_target'] ?? 0));
                })
                ->editColumn('ppspray_production', function ($row) {
                    return number_format((int)($row['ppspray_production'] ?? 0));
                })
                ->editColumn('seconddryfinal_target', function ($row) {
                    return number_format((int)($row['seconddryfinal_target'] ?? 0));
                })
                ->editColumn('seconddryfinal_production', function ($row) {
                    return number_format((int)($row['seconddryfinal_production'] ?? 0));
                })
                ->editColumn('deviation', function ($row) {
                    $deviation = (int)($row['seconddryfinal_deviation'] ?? 0);
                    $class = $deviation > 0 ? 'text-danger' : ($deviation < 0 ? 'text-success' : '');
                    return '<span class="' . $class . ' fw-bold">' . number_format($deviation) . '</span>';
                })
                ->editColumn('defect_qty', function ($row) {
                    return number_format((int)($row['total_defect_qty'] ?? 0));
                })
                ->editColumn('manPower', function ($row) {
                    return number_format((int)($row['manPower'] ?? 0));
                })
                ->editColumn('workingHr', function ($row) {
                    return number_format((float)($row['workingHr'] ?? 0), 2);
                })
                ->editColumn('smv', function ($row) {
                    return number_format((float)($row['smv'] ?? 0), 2);
                })
                ->rawColumns(['deviation'])
                ->make(true);
        } catch (\Exception $e) {
            \Log::error('Error in getSecondDryProcessData: ' . $e->getMessage());
            \Log::error('Stack trace: ' . $e->getTraceAsString());
            return DataTables::of([])->make(true);
        }
    }
    /**
     * Get Dryer Data (Aggregated by unit across date range)
     */
    public function getDryerData(Request $request)
    {
        $fromDate = $request->from_date;
        $toDate = $request->to_date;

        if (!$fromDate || !$toDate) {
            $toDate = now()->toDateString();
            $fromDate = now()->subDays(7)->toDateString();
        }

        try {
            // First, let's check if there's any data at all
            $anyData = Dryer::whereBetween('date', [$fromDate, $toDate])->get();
            \Log::info('Any Dryer Data Found:', ['count' => $anyData->count(), 'data' => $anyData->toArray()]);

            // Get all units first to ensure we have them
            $allUnits = ['Unit 1', 'Unit 2', 'Unit 3', 'Unit 4', 'Unit 5', 'Unit TWL'];

            // Get aggregated dryer data grouped by unit
            $dryerData = Dryer::select(
                'unit',
                DB::raw('COALESCE(AVG(num_dryer), 0) as avg_num_dryer'),
                DB::raw('COALESCE(AVG(avg_dryer_time), 0) as avg_avg_dryer_time'),
                DB::raw('COALESCE(AVG(avg_batch), 0) as avg_avg_batch'),
                DB::raw('COALESCE(AVG(capacity), 0) as avg_capacity'),
                // DB::raw('COALESCE(SUM(targetQty), 0) as total_targetQty'), // COMMENTED OUT
                DB::raw('COALESCE(SUM(first_wash_dryer), 0) as total_first_wash_dryer'),
                DB::raw('COALESCE(SUM(cold_dryer), 0) as total_cold_dryer'),
                DB::raw('COALESCE(SUM(measurement_correction), 0) as total_measurement_correction'),
                DB::raw('COALESCE(SUM(final_wash_dryer), 0) as total_final_wash_dryer')
            )
                ->whereBetween('date', [$fromDate, $toDate])
                ->groupBy('unit')
                ->get()
                ->keyBy('unit');

            \Log::info('Aggregated Dryer Data:', $dryerData->toArray());

            // Get delivery data (Process 316 - Send from Wash)
            $deliveryQuery = "
    SELECT 
        wop.UD_WashUnit,
        COALESCE(SUM(wop.Quantity), 0) as total_delivery
    FROM [TusukaExtreme].[dbo].[MA_WorkOrderProduction] wop
    JOIN MA_WorkOrderItem woi ON wop.WorkOrderItemId = woi.RecId
    JOIN MA_WorkOrder wo ON woi.WorkOrderId = wo.RecId
    JOIN MA_Process p ON wop.ProcessId = p.RecId
    WHERE p.RecId IN (316)
        AND wop.ProductionDate BETWEEN ? AND ?
    GROUP BY wop.UD_WashUnit
";

            $deliveryParams = [$fromDate, $toDate];
            $deliveryResults = DB::connection('sqlsrv')->select($deliveryQuery, $deliveryParams);

            // Create delivery map
            $deliveryMap = [];
            foreach ($deliveryResults as $row) {
                $unit = $row->UD_WashUnit;
                $deliveryMap[$unit] = (float)$row->total_delivery;
            }

            \Log::info('Delivery Map:', $deliveryMap);

            // Build final data array
            $finalData = [];

            foreach ($allUnits as $unit) {
                $data = $dryerData->get($unit);

                // Get values from database or use defaults
                $avgNumDryer = $data ? (float)$data->avg_num_dryer : Dryer::getUnitDryerCount($unit);
                $avgDryerTime = $data ? (float)$data->avg_avg_dryer_time : 0;
                $avgBatch = $data ? (float)$data->avg_avg_batch : 0;
                $avgCapacity = $data ? (float)$data->avg_capacity : 0;
                // $totalTargetQty = $data ? (float)$data->total_targetQty : 0; // COMMENTED OUT
                $totalFirstWash = $data ? (float)$data->total_first_wash_dryer : 0;
                $totalColdDryer = $data ? (float)$data->total_cold_dryer : 0;
                $totalMeasCorrection = $data ? (float)$data->total_measurement_correction : 0;
                $totalFinalWash = $data ? (float)$data->total_final_wash_dryer : 0;

                // Get delivery quantity
                $deliveryQty = 0;
                if (isset($deliveryMap[$unit])) {
                    $deliveryQty = $deliveryMap[$unit];
                } elseif ($unit == 'Unit 4') {
                    // Try to get from variants
                    $deliveryQty = ($deliveryMap['Unit 4 (Denim)'] ?? 0) + ($deliveryMap['Unit 4 (Dyeing)'] ?? 0);
                }

                $totalDryer = $totalFirstWash + $totalColdDryer + $totalMeasCorrection + $totalFinalWash;
                $deviation = $totalFinalWash - $deliveryQty;

                \Log::info("Processing $unit - Avg Dryer Time: $avgDryerTime, Capacity: $avgCapacity");

                $finalData[] = [
                    'unit' => $unit,
                    'num_dryer' => $avgNumDryer,
                    'avg_batch' => $avgBatch,
                    'avg_dryer_time' => $avgDryerTime,
                    'capacity' => $avgCapacity,
                    // 'target_qty' => $totalTargetQty, // COMMENTED OUT
                    'first_wash_dryer' => $totalFirstWash,
                    'cold_dryer' => $totalColdDryer,
                    'measurement_correction' => $totalMeasCorrection,
                    'final_wash_dryer' => $totalFinalWash,
                    'total_dryer' => $totalDryer,
                    'deviation_raw' => $deviation,
                    'deviation' => $deviation,
                ];
            }

            \Log::info('Final Data (raw):', $finalData);

            return DataTables::of($finalData)
                ->editColumn('unit', function ($row) {
                    return $row['unit'];
                })
                ->editColumn('num_dryer', function ($row) {
                    return (int)$row['num_dryer'];
                })
                ->editColumn('avg_batch', function ($row) {
                    return (float)$row['avg_batch'];
                })
                ->editColumn('avg_dryer_time', function ($row) {
                    return (float)$row['avg_dryer_time'];
                })
                ->editColumn('capacity', function ($row) {
                    return (float)$row['capacity'];
                })
                // ->editColumn('target_qty', function ($row) { // COMMENTED OUT
                //     return (float)$row['target_qty'];
                // })
                ->editColumn('first_wash_dryer', function ($row) {
                    return (float)$row['first_wash_dryer'];
                })
                ->editColumn('cold_dryer', function ($row) {
                    return (float)$row['cold_dryer'];
                })
                ->editColumn('measurement_correction', function ($row) {
                    return (float)$row['measurement_correction'];
                })
                ->editColumn('final_wash_dryer', function ($row) {
                    return (float)$row['final_wash_dryer'];
                })
                ->editColumn('total_dryer', function ($row) {
                    return (float)$row['total_dryer'];
                })
                ->editColumn('deviation', function ($row) {
                    $deviation = (float)$row['deviation'];
                    $class = $deviation > 0 ? 'text-success' : ($deviation < 0 ? 'text-danger' : '');
                    return '<span class="' . $class . ' fw-bold">' . number_format($deviation, 0) . '</span>';
                })
                ->rawColumns(['deviation'])
                ->make(true);
        } catch (\Exception $e) {
            Log::error('Error in getDryerData: ' . $e->getMessage());
            \Log::error('Stack trace: ' . $e->getTraceAsString());
            return DataTables::of([])->make(true);
        }
    }

    /**
     * Get Transfer Data for Dashboard
     */
    public function getTransferData(Request $request)
    {
        try {
            $fromDate = $request->from_date;
            $toDate = $request->to_date;

            if (!$fromDate || !$toDate) {
                $toDate = now()->toDateString();
                $fromDate = now()->subDays(7)->toDateString();
            }

            // Get all units
            $units = Unit::all();

            // Prepare aggregated transfer data array
            $transferData = [];

            foreach ($units as $unit) {
                // Get ALL transfers for this unit across the date range (not per date)
                $transfersIn = MachineTransfer::with(['fromUnit', 'toUnit'])
                    ->where('to_unit_id', $unit->id)
                    ->whereBetween('transfer_date', [$fromDate, $toDate])
                    ->get();

                $transfersOut = MachineTransfer::with(['fromUnit', 'toUnit'])
                    ->where('from_unit_id', $unit->id)
                    ->whereBetween('transfer_date', [$fromDate, $toDate])
                    ->get();

                // Sum total machine counts across all dates
                $transfersInCount = $transfersIn->sum('machine_count');
                $transfersOutCount = $transfersOut->sum('machine_count');

                // Format transfer in details - but now aggregated by source unit
                $transferInDetails = [];
                $transferInSummary = [];

                foreach ($transfersIn as $transfer) {
                    $fromUnitName = $transfer->fromUnit->unitName ?? 'Unknown';
                    if (!isset($transferInSummary[$fromUnitName])) {
                        $transferInSummary[$fromUnitName] = 0;
                    }
                    $transferInSummary[$fromUnitName] += $transfer->machine_count;
                }

                // Create summary strings (aggregated)
                foreach ($transferInSummary as $fromUnit => $count) {
                    $transferInDetails[] = $fromUnit . ' → ' . $count . 'MC';
                }
                $transferInText = !empty($transferInDetails) ? implode('<br>', $transferInDetails) : '-';

                // Format transfer out details - aggregated by destination unit
                $transferOutDetails = [];
                $transferOutSummary = [];

                foreach ($transfersOut as $transfer) {
                    $toUnitName = $transfer->toUnit->unitName ?? 'Unknown';
                    if (!isset($transferOutSummary[$toUnitName])) {
                        $transferOutSummary[$toUnitName] = 0;
                    }
                    $transferOutSummary[$toUnitName] += $transfer->machine_count;
                }

                // Create summary strings (aggregated)
                foreach ($transferOutSummary as $toUnit => $count) {
                    $transferOutDetails[] = $toUnit . ' → ' . $count . 'MC';
                }
                $transferOutText = !empty($transferOutDetails) ? implode('<br>', $transferOutDetails) : '-';

                // Get base machine count (using the latest date or just unit default)
                $baseMachineCount = $this->getBaseMachineCountForDate($unit->id, $toDate);

                // Calculate used machine count (base - total out + total in) across all dates
                $usedMachineCount = $baseMachineCount - $transfersOutCount + $transfersInCount;

                // Calculate MG Target per machine
                $mgTargetPerMachine = $baseMachineCount > 0 ? ($unit->mgTarget ?? 0) / $baseMachineCount : 0;
                $baseMgTarget = $unit->mgTarget ?? 0;
                $currentMgTarget = $usedMachineCount * $mgTargetPerMachine;

                // Capacity calculations
                $capacityPiecesPerMachine = $baseMachineCount > 0 ? ($unit->capacity_pieces ?? 0) / $baseMachineCount : 0;
                $capacityKgPerMachine = $baseMachineCount > 0 ? ($unit->capacity_kg ?? 0) / $baseMachineCount : 0;

                $baseCapacityPieces = $unit->capacity_pieces ?? 0;
                $baseCapacityKg = $unit->capacity_kg ?? 0;

                $currentCapacityPieces = $usedMachineCount * $capacityPiecesPerMachine;
                $currentCapacityKg = $usedMachineCount * $capacityKgPerMachine;

                // Add ONE entry per unit (not per date)
                $transferData[] = [
                    'unit' => $unit->unitName,
                    'unit_id' => $unit->id,
                    // Machine section
                    'existing_mc' => (int)$baseMachineCount,
                    'used_mc' => (int)$usedMachineCount,
                    // Transfer details (aggregated)
                    'transfer_in_details' => $transferInText,
                    'transfer_out_details' => $transferOutText,
                    'transfer_in_total' => (int)$transfersInCount,
                    'transfer_out_total' => (int)$transfersOutCount,
                    // MG Target section - ROUNDED
                    'base_mg_target' => (int)round($baseMgTarget),
                    'current_mg_target' => (int)round($currentMgTarget),
                    // Capacity Pieces section - ROUNDED
                    'base_capacity_pieces' => (int)round($baseCapacityPieces),
                    'current_capacity_pieces' => (int)round($currentCapacityPieces),
                    // Capacity KG section - ROUNDED
                    'base_capacity_kg' => (int)round($baseCapacityKg),
                    'current_capacity_kg' => (int)round($currentCapacityKg),
                ];
            }

            // Sort by unit name
            usort($transferData, function ($a, $b) {
                return strcmp($a['unit'], $b['unit']);
            });

            // Get summary statistics
            $summary = [
                'total_transfers' => MachineTransfer::whereBetween('transfer_date', [$fromDate, $toDate])->count(),
                'verified_transfers' => MachineTransfer::whereBetween('transfer_date', [$fromDate, $toDate])
                    ->where('status', 1)->count(),
                'pending_transfers' => MachineTransfer::whereBetween('transfer_date', [$fromDate, $toDate])
                    ->where('status', 0)->count(),
                'rejected_transfers' => MachineTransfer::whereBetween('transfer_date', [$fromDate, $toDate])
                    ->where('status', 2)->count(),
                'total_machines_moved' => (int)MachineTransfer::whereBetween('transfer_date', [$fromDate, $toDate])
                    ->sum('machine_count'),
            ];

            return DataTables::of($transferData)
                ->with('summary', $summary)
                ->editColumn('unit', function ($row) {
                    return '<span class="fw-bold">' . $row['unit'] . '</span>';
                })
                ->editColumn('existing_mc', function ($row) {
                    return number_format($row['existing_mc']);
                })
                ->editColumn('used_mc', function ($row) {
                    return number_format($row['used_mc']);
                })
                ->editColumn('transfer_in_details', function ($row) {
                    if ($row['transfer_in_details'] == '-') {
                        return '<span class="text-muted">-</span>';
                    }
                    return '<span class="text-success fw-bold">' . $row['transfer_in_details'] . '</span>';
                })
                ->editColumn('transfer_out_details', function ($row) {
                    if ($row['transfer_out_details'] == '-') {
                        return '<span class="text-muted">-</span>';
                    }
                    return '<span class="text-danger fw-bold">' . $row['transfer_out_details'] . '</span>';
                })
                ->editColumn('base_mg_target', function ($row) {
                    return number_format($row['base_mg_target']);
                })
                ->editColumn('current_mg_target', function ($row) {
                    $class = $row['current_mg_target'] > $row['base_mg_target'] ? 'text-success' : ($row['current_mg_target'] < $row['base_mg_target'] ? 'text-danger' : '');
                    return '<span class="' . $class . '">' . number_format($row['current_mg_target']) . '</span>';
                })
                ->editColumn('base_capacity_pieces', function ($row) {
                    return number_format($row['base_capacity_pieces']);
                })
                ->editColumn('current_capacity_pieces', function ($row) {
                    $class = $row['current_capacity_pieces'] > $row['base_capacity_pieces'] ? 'text-success' : ($row['current_capacity_pieces'] < $row['base_capacity_pieces'] ? 'text-danger' : '');
                    return '<span class="' . $class . '">' . number_format($row['current_capacity_pieces']) . '</span>';
                })
                ->editColumn('base_capacity_kg', function ($row) {
                    return number_format($row['base_capacity_kg']);
                })
                ->editColumn('current_capacity_kg', function ($row) {
                    $class = $row['current_capacity_kg'] > $row['base_capacity_kg'] ? 'text-success' : ($row['current_capacity_kg'] < $row['base_capacity_kg'] ? 'text-danger' : '');
                    return '<span class="' . $class . '">' . number_format($row['current_capacity_kg']) . '</span>';
                })
                ->rawColumns([
                    'unit',
                    'existing_mc',
                    'used_mc',
                    'transfer_in_details',
                    'transfer_out_details',
                    'base_mg_target',
                    'current_mg_target',
                    'base_capacity_pieces',
                    'current_capacity_pieces',
                    'base_capacity_kg',
                    'current_capacity_kg'
                ])
                ->make(true);
        } catch (\Exception $e) {
            \Log::error('Error in getTransferData: ' . $e->getMessage());
            return DataTables::of([])->make(true);
        }
    }

    /**
     * Helper function to get dates in range
     */
    private function getDatesInRange($startDate, $endDate)
    {
        $dates = [];
        $current = Carbon::parse($startDate);
        $end = Carbon::parse($endDate);

        while ($current <= $end) {
            $dates[] = $current->format('Y-m-d');
            $current->addDay();
        }

        return $dates;
    }

    /**
     * Helper function to get base machine count for a unit on a specific date
     */
    private function getBaseMachineCountForDate($unitId, $date)
    {
        // You can implement this based on your business logic
        // For now, returning the default machine count from the unit
        $unit = Unit::find($unitId);
        return $unit ? ($unit->machineCount ?? 0) : 0;
    }


    /**
     * Get the latest date from manpower records
     */
    public function getLatestDate()
    {
        $latestDate = WashReportManPower::max('date');

        return response()->json([
            'latest_date' => $latestDate ? Carbon::parse($latestDate)->format('d-m-Y') : 'No data found'
        ]);
    }

    /**
     * Save a new remark for a unit on a specific date
     */
    public function saveRemark(Request $request)
    {
        try {
            $request->validate([
                'unit' => 'required|string',
                'date' => 'required|date',
                'remark' => 'required|string'
            ]);

            $unit = $request->unit;
            $date = $request->date;
            $remark = $request->remark;

            // For Unit 4, we save directly to "Unit 4" in washreportentry
            if ($unit == 'Unit 4') {
                // Check if entry exists for Unit 4 on this date
                $entry = WashReportEntry::where('unit', 'Unit 4')
                    ->where('date', $date)
                    ->first();

                if ($entry) {
                    // Update existing entry
                    $entry->Remarks = $remark;
                    $entry->save();
                    $message = 'Remark updated for Unit 4 successfully!';
                } else {
                    // Create new entry with just the remark
                    $entry = WashReportEntry::create([
                        'date' => $date,
                        'unit' => 'Unit 4',
                        'FirstWashQty' => 0,
                        'AcidWashQty' => 0,
                        'FinalWashQty' => 0,
                        'ReWashQty' => 0,
                        'SewingLine' => '',
                        'Remarks' => $remark
                    ]);
                    $message = 'Remark added for Unit 4 successfully!';
                }

                return response()->json([
                    'success' => true,
                    'message' => $message,
                    'data' => $entry
                ]);
            } else {
                // For regular units, save normally
                $entry = WashReportEntry::where('unit', $unit)
                    ->where('date', $date)
                    ->first();

                if ($entry) {
                    $entry->Remarks = $remark;
                    $entry->save();
                    $message = 'Remark updated successfully!';
                } else {
                    $entry = WashReportEntry::create([
                        'date' => $date,
                        'unit' => $unit,
                        'FirstWashQty' => 0,
                        'AcidWashQty' => 0,
                        'FinalWashQty' => 0,
                        'ReWashQty' => 0,
                        'SewingLine' => '',
                        'Remarks' => $remark
                    ]);
                    $message = 'Remark added successfully!';
                }

                return response()->json([
                    'success' => true,
                    'message' => $message,
                    'data' => $entry
                ]);
            }
        } catch (\Exception $e) {
            \Log::error('Error saving remark: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error saving remark: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get remarks for a unit within date range
     */
    public function getRemarks($unit)
    {
        try {
            if ($unit == 'Unit 4') {
                // Get remarks directly from Unit 4 entries
                $remarks = WashReportEntry::where('unit', 'Unit 4')
                    ->whereNotNull('Remarks')
                    ->where('Remarks', '!=', '')
                    ->orderBy('date', 'desc')
                    ->get(['id', 'date', 'Remarks']);

                return response()->json([
                    'success' => true,
                    'data' => $remarks
                ]);
            } else {
                // Get remarks for regular unit
                $remarks = WashReportEntry::where('unit', $unit)
                    ->whereNotNull('Remarks')
                    ->where('Remarks', '!=', '')
                    ->orderBy('date', 'desc')
                    ->get(['id', 'date', 'Remarks']);

                return response()->json([
                    'success' => true,
                    'data' => $remarks
                ]);
            }
        } catch (\Exception $e) {
            \Log::error('Error getting remarks: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error getting remarks: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update an existing remark
     */
    public function updateRemark(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|integer',
                'remark' => 'required|string'
            ]);

            $entry = WashReportEntry::findOrFail($request->id);
            $entry->Remarks = $request->remark;
            $entry->save();

            return response()->json([
                'success' => true,
                'message' => 'Remark updated successfully!',
                'data' => $entry
            ]);
        } catch (\Exception $e) {
            \Log::error('Error updating remark: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error updating remark: ' . $e->getMessage()
            ], 500);
        }
    }

/**
 * Convert time format (HH:MM:SS or HH:MM) to decimal hours
 * Handles formats like "286:38:28" or "265:56:48"
 */
    private function convertTimeToDecimalHours($timeString)
    {
        if (empty($timeString) || $timeString == '-') {
            return 0;
        }
        
        // Remove any whitespace
        $timeString = trim($timeString);
        
        // Split by colon
        $parts = explode(':', $timeString);
        
        if (count($parts) == 3) {
            // Format: HH:MM:SS
            $hours = (int)$parts[0];
            $minutes = (int)$parts[1];
            $seconds = (int)$parts[2];
            
            return $hours + ($minutes / 60) + ($seconds / 3600);
        } elseif (count($parts) == 2) {
            // Format: HH:MM
            $hours = (int)$parts[0];
            $minutes = (int)$parts[1];
            
            return $hours + ($minutes / 60);
        }
        
        return 0;
    }

    public function getCappMachineStatus(Request $request)
    {
        try {
            // Get date from request
            $fromDate = $request->from_date;
            $toDate = $request->to_date;

            // If no dates provided, use today
            if (!$fromDate || !$toDate) {
                $fromDate = now()->toDateString();
                $toDate = now()->toDateString();
            }

            // Define the unit mappings with their correct API endpoints
            $unitApis = [
                'Unit 1' => 'http://192.168.10.38/tusuka-wms/api/machines/statistic-data/rabiul_mis@tusuka.com/7/13',
                'Unit 2' => 'http://192.168.10.38/tusuka-wms/api/machines/statistic-data/rabiul_mis@tusuka.com/7/14',
                'Unit 3' => 'http://192.168.10.38/tusuka-wms/api/machines/statistic-data/rabiul_mis@tusuka.com/7/18',
                'Unit 4' => 'http://192.168.10.38/tusuka-wms/api/machines/statistic-data/rabiul_mis@tusuka.com/7/19',
                'Unit 5' => 'http://192.168.10.38/tusuka-wms/api/machines/statistic-data/rabiul_mis@tusuka.com/7/20',
                'Unit TWL' => 'http://192.168.10.38/tusuka-wms/api/machines/statistic-data/rabiul_mis@tusuka.com/8/23'
            ];

            // Define the unit order (EXCLUDING Unit 5)
            $unitOrder = ['Unit 1', 'Unit 2', 'Unit 3', 'Unit 4', 'Unit TWL'];

            $unitData = [];
            $periodFrom = '';
            $periodTo = '';

            // Initialize cURL multi handle for parallel requests
            $mh = curl_multi_init();
            $curlHandles = [];

            // Create cURL handles for each unit
            foreach ($unitApis as $unit => $url) {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

                curl_multi_add_handle($mh, $ch);
                $curlHandles[$unit] = $ch;
            }

            // Execute all requests simultaneously
            $running = null;
            do {
                curl_multi_exec($mh, $running);
                curl_multi_select($mh);
            } while ($running > 0);

            // Get all responses and save to database
            foreach ($curlHandles as $unit => $ch) {
                $response = curl_multi_getcontent($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

                if ($httpCode === 200 && $response) {
                    $data = json_decode($response, true);

                    // Log the response for debugging
                    \Log::info("API Response for {$unit}:", ['data' => $data]);

                    // 🔥 FIXED: Handle both TPL and TWL structures
                    if ($data) {
                        // Case 1: Handle TWL structure (top-level key is 'TWL')
                        if (isset($data['TWL'])) {
                            foreach ($data['TWL'] as $unitKey => $unitStats) {
                                $mappedUnit = $this->mapApiUnitToDashboardUnit('TWL');

                                if ($mappedUnit && in_array($mappedUnit, $unitOrder)) {
                                    // Store in unitData array for response
                                    $unitData[$mappedUnit] = [
                                        'uptime' => $unitStats['uptime'] ?? 0,
                                        'idletime' => $unitStats['idletime'] ?? 0,
                                        'downtime' => $unitStats['downtime'] ?? 0,
                                        'up_duration' => $unitStats['up_duration'] ?? '',
                                        'idle_duration' => $unitStats['idle_duration'] ?? '',
                                        'down_duration' => $unitStats['down_duration'] ?? '',
                                    ];

                                    // SAVE TO DATABASE for today's date
                                    \App\Models\MachineStatus::updateOrCreate(
                                        [
                                            'unit' => $mappedUnit,
                                            'report_date' => now()->toDateString()
                                        ],
                                        [
                                            'plant' => 'TWL',
                                            'machine_group' => $unitKey,
                                            'uptime' => $unitStats['uptime'] ?? 0,
                                            'idletime' => $unitStats['idletime'] ?? 0,
                                            'downtime' => $unitStats['downtime'] ?? 0,
                                            'up_duration' => $unitStats['up_duration'] ?? '',
                                            'idle_duration' => $unitStats['idle_duration'] ?? '',
                                            'down_duration' => $unitStats['down_duration'] ?? '',
                                            'fetched_at' => now()
                                        ]
                                    );

                                    \Log::info("Saved TWL data for {$mappedUnit}");
                                }
                            }
                        }

                        // Case 2: Handle TPL structure (top-level key is 'TPL')
                        elseif (isset($data['TPL'])) {
                            foreach ($data['TPL'] as $unitKey => $unitStats) {
                                $mappedUnit = $this->mapApiUnitToDashboardUnit($unitKey);

                                if ($mappedUnit && in_array($mappedUnit, $unitOrder)) {
                                    // Store in unitData array for response
                                    $unitData[$mappedUnit] = [
                                        'uptime' => $unitStats['uptime'] ?? 0,
                                        'idletime' => $unitStats['idletime'] ?? 0,
                                        'downtime' => $unitStats['downtime'] ?? 0,
                                        'up_duration' => $unitStats['up_duration'] ?? '',
                                        'idle_duration' => $unitStats['idle_duration'] ?? '',
                                        'down_duration' => $unitStats['down_duration'] ?? '',
                                    ];

                                    // SAVE TO DATABASE for today's date
                                    \App\Models\MachineStatus::updateOrCreate(
                                        [
                                            'unit' => $mappedUnit,
                                            'report_date' => now()->toDateString()
                                        ],
                                        [
                                            'plant' => 'TPL',
                                            'machine_group' => $unitKey,
                                            'uptime' => $unitStats['uptime'] ?? 0,
                                            'idletime' => $unitStats['idletime'] ?? 0,
                                            'downtime' => $unitStats['downtime'] ?? 0,
                                            'up_duration' => $unitStats['up_duration'] ?? '',
                                            'idle_duration' => $unitStats['idle_duration'] ?? '',
                                            'down_duration' => $unitStats['down_duration'] ?? '',
                                            'fetched_at' => now()
                                        ]
                                    );

                                    \Log::info("Saved TPL data for {$mappedUnit}");
                                }
                            }
                        }

                        // Use the first unit's period info (if available)
                        if (empty($periodFrom)) {
                            if (isset($data['TPL'])) {
                                $firstUnit = reset($data['TPL']);
                                if (isset($firstUnit['from'])) {
                                    $periodFrom = $firstUnit['from'];
                                    $periodTo = $firstUnit['to'];
                                }
                            } elseif (isset($data['TWL'])) {
                                $firstUnit = reset($data['TWL']);
                                if (isset($firstUnit['from'])) {
                                    $periodFrom = $firstUnit['from'];
                                    $periodTo = $firstUnit['to'];
                                }
                            }
                        }
                    }
                } else {
                    \Log::warning("Failed to fetch data for {$unit}. HTTP Code: {$httpCode}");
                }
                curl_multi_remove_handle($mh, $ch);
                curl_close($ch);
            }
            curl_multi_close($mh);

            // Now, get the AVERAGE data from database for the requested date range
            $sortedUptime = [];
            $sortedIdletime = [];
            $sortedDowntime = [];
            $sortedUnitData = [];

            foreach ($unitOrder as $unit) {
                // Get average data from database for the selected date range
                $statusData = \App\Models\MachineStatus::where('unit', $unit)
                    ->whereBetween('report_date', [$fromDate, $toDate])
                    ->selectRaw('AVG(uptime) as avg_uptime, AVG(idletime) as avg_idletime, AVG(downtime) as avg_downtime')
                    ->first();

                if ($statusData && $statusData->avg_uptime !== null) {
                    $sortedUptime[] = round($statusData->avg_uptime, 2);
                    $sortedIdletime[] = round($statusData->avg_idletime, 2);
                    $sortedDowntime[] = round($statusData->avg_downtime, 2);

                    $sortedUnitData[$unit] = [
                        'uptime' => round($statusData->avg_uptime, 2),
                        'idletime' => round($statusData->avg_idletime, 2),
                        'downtime' => round($statusData->avg_downtime, 2)
                    ];
                } else {
                    // If no data in DB for this range, use today's fetched data as fallback
                    if (isset($unitData[$unit])) {
                        $sortedUptime[] = $unitData[$unit]['uptime'] ?? 0;
                        $sortedIdletime[] = $unitData[$unit]['idletime'] ?? 0;
                        $sortedDowntime[] = $unitData[$unit]['downtime'] ?? 0;

                        $sortedUnitData[$unit] = [
                            'uptime' => $unitData[$unit]['uptime'] ?? 0,
                            'idletime' => $unitData[$unit]['idletime'] ?? 0,
                            'downtime' => $unitData[$unit]['downtime'] ?? 0
                        ];
                    } else {
                        $sortedUptime[] = 0;
                        $sortedIdletime[] = 0;
                        $sortedDowntime[] = 0;

                        $sortedUnitData[$unit] = [
                            'uptime' => 0,
                            'idletime' => 0,
                            'downtime' => 0
                        ];
                    }
                }
            }

            // Format the data for the chart
            $chartData = [
                'labels' => $unitOrder,
                'datasets' => [
                    [
                        'label' => 'Downtime (%)',
                        'data' => $sortedDowntime,
                        'backgroundColor' => 'rgba(220, 53, 69, 0.7)',
                        'borderColor' => 'rgba(220, 53, 69, 1)',
                        'borderWidth' => 1
                    ],
                    [
                        'label' => 'Idletime (%)',
                        'data' => $sortedIdletime,
                        'backgroundColor' => 'rgba(255, 193, 7, 0.7)',
                        'borderColor' => 'rgba(255, 193, 7, 1)',
                        'borderWidth' => 1
                    ],
                    [
                        'label' => 'Uptime (%)',
                        'data' => $sortedUptime,
                        'backgroundColor' => 'rgba(40, 167, 69, 0.7)',
                        'borderColor' => 'rgba(40, 167, 69, 1)',
                        'borderWidth' => 1
                    ]
                ]
            ];

            return response()->json([
                'success' => true,
                'chart_data' => $chartData,
                'unit_data' => $sortedUnitData,
                'period' => [
                    'from' => $fromDate,
                    'to' => $toDate,
                    'api_from' => $periodFrom,
                    'api_to' => $periodTo
                ]
            ]);
        } catch (\Exception $e) {
            \Log::error('CAPP API Error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error fetching machine status: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Map API unit names to dashboard unit names
     */
    private function mapApiUnitToDashboardUnit($apiUnit)
    {
        $mapping = [
            'Unit-1' => 'Unit 1',
            'Unit-2' => 'Unit 2',
            'Unit-3' => 'Unit 3',
            'Unit-4' => 'Unit 4',
            'Unit-5' => 'Unit 5',
            'TWL' => 'Unit TWL',      // Add this for TWL structure
            'Unit-TWL' => 'Unit TWL', // Keep existing for consistency
        ];

        return $mapping[$apiUnit] ?? null;
    }


    public function downloadPdf(Request $request)
    {
        try {
            $fromDate = $request->from_date;
            $toDate = $request->to_date;

            if (!$fromDate || !$toDate) {
                $toDate = now()->toDateString();
                $fromDate = now()->subDays(7)->toDateString();
            }

            // 1. Get Unit Data & Totals (Same logic)
            $unitDataRequest = new Request(['from_date' => $fromDate, 'to_date' => $toDate]);
            $unitDataResponse = $this->getUnitData($unitDataRequest);
            $unitData = $unitDataResponse->getData()->data ?? [];

            $unitTotals = [
                'machines' => 0,
                'capacity_kg' => 0,
                'direct' => 0,
                'indirect' => 0,
                'total' => 0,
                'work_hours' => 0,
                'smv' => 0,
                'received' => 0,
                'delivery' => 0,
                'forecast_target' => 0,
                'deviation' => 0,
                'deviation_percent' => 0,
                'wash_ratio' => 0,
                'rewash_percent' => 0,
                'first_wash_qty' => 0,
                'acid_wash_qty' => 0,
                'final_wash_qty' => 0,
                'rewash_qty' => 0,
                'rework_dry_proc' => 0
            ];
            $unitCount = count($unitData);

            foreach ($unitData as $u) {
                if (is_array($u)) {
                    $u = (object) $u;
                }

                $unitTotals['machines'] += (int)($u->machines ?? 0);
                $unitTotals['capacity_kg'] += (float)($u->capacity_kg ?? 0);
                $unitTotals['direct'] += (int)($u->direct ?? 0);
                $unitTotals['indirect'] += (int)($u->indirect ?? 0);
                $unitTotals['total'] += (int)($u->total ?? 0);
                $unitTotals['work_hours'] += (float)($u->work_hours ?? 0);
                $unitTotals['smv'] += (float)($u->smv ?? 0);
                $received = 0;
                if (isset($u->received)) {
                    if (is_string($u->received)) {
                        $received = (int) str_replace(',', '', $u->received);
                    } else {
                        $received = (int) $u->received;
                    }
                }
                $unitTotals['received'] += $received;
                $delivery = 0;
                if (isset($u->delivery)) {
                    if (is_string($u->delivery)) {
                        $delivery = (int) str_replace(',', '', $u->delivery);
                    } else {
                        $delivery = (int) $u->delivery;
                    }
                }
                $unitTotals['delivery'] += $delivery;
                // FORECAST TARGET - FIXED
                $forecast = 0;
                if (isset($u->forecast_target)) {
                    if (is_string($u->forecast_target)) {
                        $forecast = (float) str_replace(',', '', $u->forecast_target);
                    } else {
                        $forecast = (float) $u->forecast_target;
                    }
                }
                $unitTotals['forecast_target'] += $forecast;
                // FIRST WASH - FIXED
                $firstWash = 0;
                if (isset($u->first_wash_qty)) {
                    if (is_string($u->first_wash_qty)) {
                        $firstWash = (int) str_replace(',', '', $u->first_wash_qty);
                    } else {
                        $firstWash = (int) $u->first_wash_qty;
                    }
                }
                $unitTotals['first_wash_qty'] += $firstWash;
                // ACID WASH - FIXED
                $acidWash = 0;
                if (isset($u->acid_wash_qty)) {
                    if (is_string($u->acid_wash_qty)) {
                        $acidWash = (int) str_replace(',', '', $u->acid_wash_qty);
                    } else {
                        $acidWash = (int) $u->acid_wash_qty;
                    }
                }
                $unitTotals['acid_wash_qty'] += $acidWash;
                // FINAL WASH - FIXED
                $finalWash = 0;
                if (isset($u->final_wash_qty)) {
                    if (is_string($u->final_wash_qty)) {
                        $finalWash = (int) str_replace(',', '', $u->final_wash_qty);
                    } else {
                        $finalWash = (int) $u->final_wash_qty;
                    }
                }
                $unitTotals['final_wash_qty'] += $finalWash;
                // REWASH QTY - FIXED
                $rewash = 0;
                if (isset($u->rewash_qty)) {
                    if (is_string($u->rewash_qty)) {
                        $rewash = (int) str_replace(',', '', $u->rewash_qty);
                    } else {
                        $rewash = (int) $u->rewash_qty;
                    }
                }
                $unitTotals['rewash_qty'] += $rewash;
                // REWORK DRY PROC - FIXED
                $reworkDryProc = 0;
                if (isset($u->rework_dry_proc)) {
                    if (is_string($u->rework_dry_proc)) {
                        // Remove commas from formatted numbers
                        $clean = str_replace(',', '', $u->rework_dry_proc);
                        $reworkDryProc = (int) $clean;
                    } else {
                        $reworkDryProc = (int) $u->rework_dry_proc;
                    }
                }
                $unitTotals['rework_dry_proc'] += $reworkDryProc;

                $cleanNumber = function ($val) {
                    return (float)filter_var($val, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                };

                // DEVIATION - FIXED
                $deviation = 0;
                if (isset($u->deviation)) {
                    if (is_string($u->deviation)) {
                        // Remove HTML tags first
                        $clean = strip_tags($u->deviation);
                        // Remove commas
                        $clean = str_replace(',', '', $clean);
                        // Parse as float
                        $deviation = (float) $clean;
                    } else {
                        $deviation = (float) $u->deviation;
                    }
                }
                $unitTotals['deviation'] += $deviation;
                // DEVIATION PERCENT - FIXED
                $deviationPercent = 0;
                if (isset($u->deviation_percent)) {
                    if (is_string($u->deviation_percent)) {
                        // Remove HTML tags first
                        $clean = strip_tags($u->deviation_percent);
                        // Remove commas
                        $clean = str_replace(',', '', $clean);
                        // Remove % sign
                        $clean = str_replace('%', '', $clean);
                        // Parse as float
                        $deviationPercent = (float) $clean;
                    } else {
                        $deviationPercent = (float) $u->deviation_percent;
                    }
                }
                $unitTotals['deviation_percent'] += $deviationPercent;
                $unitTotals['wash_ratio'] += $cleanNumber($u->wash_ratio ?? 0);
                $unitTotals['rewash_percent'] += $cleanNumber($u->rewash_percent ?? 0);
            }

            // 2. Get First Dry Data & Totals
            $firstDryRequest = new Request(['from_date' => $fromDate, 'to_date' => $toDate]);
            $firstDryResponse = $this->getFirstDryProcessData($firstDryRequest);
            $firstDryData = $firstDryResponse->getData()->data ?? [];
            $firstDryTotals = [
                'whisker_target' => 0,
                'whisker_prod' => 0,
                'handbrush_target' => 0,
                'handbrush_prod' => 0,
                'target' => 0,
                'prod' => 0,
                'deviation' => 0,
                'defect' => 0,
                'manpower' => 0
            ];

            foreach ($firstDryData as $d) {
                // Handle whisker target
                $whiskerTarget = 0;
                if (isset($d->whisker_target)) {
                    if (is_string($d->whisker_target)) {
                        $whiskerTarget = (int) str_replace(',', '', $d->whisker_target);
                    } else {
                        $whiskerTarget = (int) $d->whisker_target;
                    }
                }
                $firstDryTotals['whisker_target'] += $whiskerTarget;

                // Handle whisker production
                $whiskerProd = 0;
                if (isset($d->whisker_production)) {
                    if (is_string($d->whisker_production)) {
                        $whiskerProd = (int) str_replace(',', '', $d->whisker_production);
                    } else {
                        $whiskerProd = (int) $d->whisker_production;
                    }
                }
                $firstDryTotals['whisker_prod'] += $whiskerProd;

                // Handle handbrush target
                $handbrushTarget = 0;
                if (isset($d->handbrush_target)) {
                    if (is_string($d->handbrush_target)) {
                        $handbrushTarget = (int) str_replace(',', '', $d->handbrush_target);
                    } else {
                        $handbrushTarget = (int) $d->handbrush_target;
                    }
                }
                $firstDryTotals['handbrush_target'] += $handbrushTarget;

                // Handle handbrush production
                $handbrushProd = 0;
                if (isset($d->handbrush_production)) {
                    if (is_string($d->handbrush_production)) {
                        $handbrushProd = (int) str_replace(',', '', $d->handbrush_production);
                    } else {
                        $handbrushProd = (int) $d->handbrush_production;
                    }
                }
                $firstDryTotals['handbrush_prod'] += $handbrushProd;

                // Handle first dry final target
                $target = 0;
                if (isset($d->firstdryfinal_target)) {
                    if (is_string($d->firstdryfinal_target)) {
                        $target = (int) str_replace(',', '', $d->firstdryfinal_target);
                    } else {
                        $target = (int) $d->firstdryfinal_target;
                    }
                }
                $firstDryTotals['target'] += $target;

                // Handle first dry final production
                $prod = 0;
                if (isset($d->firstdryfinal_production)) {
                    if (is_string($d->firstdryfinal_production)) {
                        $prod = (int) str_replace(',', '', $d->firstdryfinal_production);
                    } else {
                        $prod = (int) $d->firstdryfinal_production;
                    }
                }
                $firstDryTotals['prod'] += $prod;

                // Handle defect
                $defect = 0;
                if (isset($d->defect_qty)) {
                    if (is_string($d->defect_qty)) {
                        $defect = (int) str_replace(',', '', $d->defect_qty);
                    } else {
                        $defect = (int) $d->defect_qty;
                    }
                }
                $firstDryTotals['defect'] += $defect;

                // Handle manpower
                $manpower = 0;
                if (isset($d->manPower)) {
                    if (is_string($d->manPower)) {
                        $manpower = (int) str_replace(',', '', $d->manPower);
                    } else {
                        $manpower = (int) $d->manPower;
                    }
                }
                $firstDryTotals['manpower'] += $manpower;

                // Handle deviation
                $deviation = 0;
                if (isset($d->deviation)) {
                    if (is_string($d->deviation)) {
                        // Remove HTML tags first
                        $clean = strip_tags($d->deviation);
                        // Remove commas
                        $clean = str_replace(',', '', $clean);
                        $deviation = (float) $clean;
                    } else {
                        $deviation = (float) $d->deviation;
                    }
                }
                $firstDryTotals['deviation'] += $deviation;
            }

            // 3. Get Second Dry Data & Totals
            $secondDryRequest = new Request(['from_date' => $fromDate, 'to_date' => $toDate]);
            $secondDryResponse = $this->getSecondDryProcessData($secondDryRequest);
            $secondDryData = $secondDryResponse->getData()->data ?? [];
            $secondDryTotals = [
                'laser_target' => 0,
                'laser_prod' => 0,
                'ppspray_target' => 0,
                'ppspray_prod' => 0,
                'target' => 0,
                'prod' => 0,
                'deviation' => 0,
                'defect' => 0,
                'manpower' => 0
            ];

            foreach ($secondDryData as $d) {
                // Handle laser target
                $laserTarget = 0;
                if (isset($d->laser_target)) {
                    if (is_string($d->laser_target)) {
                        $laserTarget = (int) str_replace(',', '', $d->laser_target);
                    } else {
                        $laserTarget = (int) $d->laser_target;
                    }
                }
                $secondDryTotals['laser_target'] += $laserTarget;

                // Handle laser production
                $laserProd = 0;
                if (isset($d->laser_production)) {
                    if (is_string($d->laser_production)) {
                        $laserProd = (int) str_replace(',', '', $d->laser_production);
                    } else {
                        $laserProd = (int) $d->laser_production;
                    }
                }
                $secondDryTotals['laser_prod'] += $laserProd;

                // Handle PP Spray target
                $ppTarget = 0;
                if (isset($d->ppspray_target)) {
                    if (is_string($d->ppspray_target)) {
                        $ppTarget = (int) str_replace(',', '', $d->ppspray_target);
                    } else {
                        $ppTarget = (int) $d->ppspray_target;
                    }
                }
                $secondDryTotals['ppspray_target'] += $ppTarget;

                // Handle PP Spray production
                $ppProd = 0;
                if (isset($d->ppspray_production)) {
                    if (is_string($d->ppspray_production)) {
                        $ppProd = (int) str_replace(',', '', $d->ppspray_production);
                    } else {
                        $ppProd = (int) $d->ppspray_production;
                    }
                }
                $secondDryTotals['ppspray_prod'] += $ppProd;

                // Handle second dry final target
                $target = 0;
                if (isset($d->seconddryfinal_target)) {
                    if (is_string($d->seconddryfinal_target)) {
                        $target = (int) str_replace(',', '', $d->seconddryfinal_target);
                    } else {
                        $target = (int) $d->seconddryfinal_target;
                    }
                }
                $secondDryTotals['target'] += $target;

                // Handle second dry final production
                $prod = 0;
                if (isset($d->seconddryfinal_production)) {
                    if (is_string($d->seconddryfinal_production)) {
                        $prod = (int) str_replace(',', '', $d->seconddryfinal_production);
                    } else {
                        $prod = (int) $d->seconddryfinal_production;
                    }
                }
                $secondDryTotals['prod'] += $prod;

                // Handle defect
                $defect = 0;
                if (isset($d->defect_qty)) {
                    if (is_string($d->defect_qty)) {
                        $defect = (int) str_replace(',', '', $d->defect_qty);
                    } else {
                        $defect = (int) $d->defect_qty;
                    }
                }
                $secondDryTotals['defect'] += $defect;

                // Handle manpower
                $manpower = 0;
                if (isset($d->manPower)) {
                    if (is_string($d->manPower)) {
                        $manpower = (int) str_replace(',', '', $d->manPower);
                    } else {
                        $manpower = (int) $d->manPower;
                    }
                }
                $secondDryTotals['manpower'] += $manpower;

                // Handle deviation
                $deviation = 0;
                if (isset($d->deviation)) {
                    if (is_string($d->deviation)) {
                        // Remove HTML tags first
                        $clean = strip_tags($d->deviation);
                        // Remove commas
                        $clean = str_replace(',', '', $clean);
                        $deviation = (float) $clean;
                    } else {
                        $deviation = (float) $d->deviation;
                    }
                }
                $secondDryTotals['deviation'] += $deviation;
            }

            // 4. Get Transfer Data & Totals
            $transferRequest = new Request(['from_date' => $fromDate, 'to_date' => $toDate]);
            $transferResponse = $this->getTransferData($transferRequest);
            $transferData = $transferResponse->getData()->data ?? [];
            $transferTotals = ['existing_mc' => 0, 'used_mc' => 0, 'current_mg' => 0, 'current_pcs' => 0, 'current_kg' => 0];

            // Create plain text versions for PDF
            foreach ($transferData as $item) {
                // Clean transfer in details
                if (isset($item->transfer_in_details)) {
                    $clean = strip_tags($item->transfer_in_details);
                    $clean = str_replace('→', '-', $clean);
                    $item->transfer_in_details_pdf = $clean;
                } else {
                    $item->transfer_in_details_pdf = '-';
                }

                // Clean transfer out details
                if (isset($item->transfer_out_details)) {
                    $clean = strip_tags($item->transfer_out_details);
                    $clean = str_replace('→', '-', $clean);
                    $item->transfer_out_details_pdf = $clean;
                } else {
                    $item->transfer_out_details_pdf = '-';
                }
            }

            foreach ($transferData as $t) {
                $transferTotals['existing_mc'] += (int)($t->existing_mc ?? 0);
                $transferTotals['used_mc'] += (int)($t->used_mc ?? 0);
                $transferTotals['current_mg'] += (int)filter_var($t->current_mg_target ?? 0, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                $transferTotals['current_pcs'] += (int)filter_var($t->current_capacity_pieces ?? 0, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                $transferTotals['current_kg'] += (int)filter_var($t->current_capacity_kg ?? 0, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            }

            // 5. Get Dryer Data & Totals
            $dryerRequest = new Request(['from_date' => $fromDate, 'to_date' => $toDate]);
            $dryerResponse = $this->getDryerData($dryerRequest);
            $dryerData = $dryerResponse->getData()->data ?? [];
            $dryerTotals = ['num_dryer' => 0, 'target' => 0, 'first_wash' => 0, 'cold' => 0, 'meas' => 0, 'final_wash' => 0, 'total' => 0, 'deviation' => 0];
            foreach ($dryerData as $d) {
                $dryerTotals['num_dryer'] += (int)($d->num_dryer ?? 0);
                $dryerTotals['target'] += (float)($d->target_qty ?? 0);
                $dryerTotals['first_wash'] += (float)($d->first_wash_dryer ?? 0);
                $dryerTotals['cold'] += (float)($d->cold_dryer ?? 0);
                $dryerTotals['meas'] += (float)($d->measurement_correction ?? 0);
                $dryerTotals['final_wash'] += (float)($d->final_wash_dryer ?? 0);
                $dryerTotals['total'] += (float)($d->total_dryer ?? 0);

                // DEVIATION - FIXED: Handle HTML and commas properly
                $deviation = 0;
                if (isset($d->deviation)) {
                    if (is_string($d->deviation)) {
                        // Remove HTML tags first
                        $clean = strip_tags($d->deviation);
                        // Remove commas
                        $clean = str_replace(',', '', $clean);
                        // Trim
                        $clean = trim($clean);
                        // Parse as float
                        $deviation = (float) $clean;
                    } else {
                        $deviation = (float) $d->deviation;
                    }
                }
                $dryerTotals['deviation'] += $deviation;
            }

            // 6. Get CAPP Data
            $cappRequest = new Request([
                'from_date' => $fromDate,
                'to_date' => $toDate
            ]);
            $cappResponse = $this->getCappMachineStatus($cappRequest);
            $cappData = $cappResponse->getData(true);

            // --- GENERATE CHART LOCALLY AND SAVE TO FILE ---
            $chartPath = null;

            if (!empty($cappData['success'])) {
                $labels = $cappData['chart_data']['labels'];
                $downtimeData = $cappData['chart_data']['datasets'][0]['data'];
                $idletimeData = $cappData['chart_data']['datasets'][1]['data'];
                $uptimeData = $cappData['chart_data']['datasets'][2]['data'];

                try {
                    // Generate chart and get file path
                    $chartPath = $this->generateLocalChart($labels, $downtimeData, $idletimeData, $uptimeData);
                    \Log::info('Chart saved to: ' . $chartPath);
                } catch (\Exception $e) {
                    \Log::error('Local chart generation failed: ' . $e->getMessage());
                    $chartPath = null;
                }
            }

            // -------------------------------------


            // Generate PDF
            $pdf = Pdf::loadView('backend.wash-report-dashboard.pdf', [
                'fromDate' => $fromDate,
                'toDate' => $toDate,
                'unitData' => $unitData,
                'unitTotals' => $unitTotals,
                'unitCount' => $unitCount,
                'firstDryData' => $firstDryData,
                'firstDryTotals' => $firstDryTotals,
                'secondDryData' => $secondDryData,
                'secondDryTotals' => $secondDryTotals,
                'transferData' => $transferData,
                'transferTotals' => $transferTotals,
                'dryerData' => $dryerData,
                'dryerTotals' => $dryerTotals,
                'chartPath' => $chartPath // Use file path instead of base64
            ]);

            $pdf->setPaper('A4', 'landscape');
            $filename = 'Wash_Report_' . Carbon::parse($fromDate)->format('d-m-Y') . '_to_' . Carbon::parse($toDate)->format('d-m-Y') . '.pdf';

            // Get PDF content
            $pdfContent = $pdf->output();

            // Clean up temp file if it exists
            if ($chartPath && file_exists($chartPath)) {
                unlink($chartPath);
                \Log::info('Temp chart file deleted: ' . $chartPath);
            }

            // Return download response
            return response()->streamDownload(
                fn() => print($pdfContent),
                $filename
            );
        } catch (\Exception $e) {
            \Log::error('PDF Generation Error: ' . $e->getMessage());

            // Clean up temp file if it exists (in case of error)
            if (isset($chartPath) && $chartPath && file_exists($chartPath)) {
                unlink($chartPath);
            }

            return response()->json([
                'success' => false,
                'message' => 'Error generating PDF: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Generate a bar chart image locally using GD and save to file
     */
    private function generateLocalChart($labels, $downtimeData, $idletimeData, $uptimeData)
    {
        $width = 1000;
        $height = 250;
        $padding = 50;
        $bottomPadding = 50;

        $chartWidth = $width - (2 * $padding);
        $chartHeight = $height - $padding - $bottomPadding;

        $maxScale = 70;

        $image = imagecreatetruecolor($width, $height);
        imageantialias($image, true);

        // Colors
        $white = imagecolorallocate($image, 255, 255, 255);
        $black = imagecolorallocate($image, 0, 0, 0);
        $gray = imagecolorallocate($image, 240, 240, 240);
        $darkGray = imagecolorallocate($image, 150, 150, 150);

        $red = imagecolorallocate($image, 220, 53, 69);
        $yellow = imagecolorallocate($image, 255, 193, 7);
        $green = imagecolorallocate($image, 40, 167, 69);
        $blue = imagecolorallocate($image, 0, 123, 255);

        // Background
        imagefill($image, 0, 0, $white);

        // Title
        $title = 'Machine Performance';
        $titleX = ($width - (strlen($title) * imagefontwidth(4))) / 2;
        imagestring($image, 4, $titleX, 5, $title, $blue);

        // Border
        imagerectangle($image, 1, 1, $width - 2, $height - 2, $darkGray);

        /*
    |--------------------------------------------------------------------------
    | Grid Lines
    |--------------------------------------------------------------------------
    */

        for ($i = 0; $i <= 5; $i++) {

            $percentage = ($i * $maxScale) / 5;

            $y = $padding + ($chartHeight * (5 - $i) / 5);

            imageline($image, $padding - 5, $y, $width - $padding + 5, $y, $gray);

            imagestring($image, 2, 10, $y - 6, round($percentage) . '%', $black);
        }

        imageline(
            $image,
            $padding - 5,
            $padding - 5,
            $padding - 5,
            $height - $bottomPadding + 5,
            $black
        );

        /*
    |--------------------------------------------------------------------------
    | Layout Settings
    |--------------------------------------------------------------------------
    */

        $barGroups = max(1, count($labels));

        $groupWidth = $chartWidth / $barGroups;

        /*
    ⭐ Each group has 3 bars → divide group space into 3 slots
    */

        $slotWidth = $groupWidth * 0.7;
        $barWidth = $slotWidth / 3;

        /*
    Inside group gap between bars
    */
        $barGap = 6;

        /*
    |--------------------------------------------------------------------------
    | Draw Bars
    |--------------------------------------------------------------------------
    */

        for ($i = 0; $i < $barGroups; $i++) {

            $groupX = $padding + ($i * $groupWidth) + ($groupWidth * 0.15);

            $label = $labels[$i] ?? '';

            /*
        ----------------------
        Center Unit Label
        ----------------------
        */

            $labelTextWidth = strlen($label) * 3;

            $labelX = $groupX + ($slotWidth / 2) - $labelTextWidth;

            imagestring(
                $image,
                3,
                $labelX,
                $height - 30,
                $label,
                $black
            );

            /*
        ===============================
        Downtime Bar
        ===============================
        */

            $baseY = $height - $bottomPadding;

            $value = $downtimeData[$i] ?? 0;
            $barHeight = ($value / $maxScale) * $chartHeight;

            $x1 = $groupX;
            $y1 = $baseY - $barHeight;

            $x2 = $x1 + $barWidth;

            imagefilledrectangle($image, $x1, $y1, $x2, $baseY, $red);

            imagestring(
                $image,
                1,
                $x1,
                $y1 - 12,
                round($value, 1) . '%',
                $black
            );

            /*
        ===============================
        Idletime Bar
        ===============================
        */

            $value = $idletimeData[$i] ?? 0;
            $barHeight = ($value / $maxScale) * $chartHeight;

            $x1 = $groupX + $barWidth + $barGap;
            $y1 = $baseY - $barHeight;
            $x2 = $x1 + $barWidth;

            imagefilledrectangle($image, $x1, $y1, $x2, $baseY, $yellow);

            imagestring(
                $image,
                1,
                $x1,
                $y1 - 12,
                round($value, 1) . '%',
                $black
            );

            /*
        ===============================
        Uptime Bar
        ===============================
        */

            $value = $uptimeData[$i] ?? 0;
            $barHeight = ($value / $maxScale) * $chartHeight;

            $x1 = $groupX + 2 * ($barWidth + $barGap);
            $y1 = $baseY - $barHeight;
            $x2 = $x1 + $barWidth;

            imagefilledrectangle($image, $x1, $y1, $x2, $baseY, $green);

            imagestring(
                $image,
                1,
                $x1,
                $y1 - 12,
                round($value, 1) . '%',
                $black
            );
        }

        /*
    |--------------------------------------------------------------------------
    | Legend
    |--------------------------------------------------------------------------
    */

        $legendY = 30;

        imagefilledrectangle(
            $image,
            $padding,
            $legendY - 5,
            $padding + 12,
            $legendY + 5,
            $red
        );

        imagestring(
            $image,
            2,
            $padding + 15,
            $legendY - 5,
            'Downtime',
            $black
        );

        imagefilledrectangle(
            $image,
            $padding + 100,
            $legendY - 5,
            $padding + 112,
            $legendY + 5,
            $yellow
        );

        imagestring(
            $image,
            2,
            $padding + 115,
            $legendY - 5,
            'Idletime',
            $black
        );

        imagefilledrectangle(
            $image,
            $padding + 200,
            $legendY - 5,
            $padding + 212,
            $legendY + 5,
            $green
        );

        imagestring(
            $image,
            2,
            $padding + 215,
            $legendY - 5,
            'Uptime',
            $black
        );

        /*
    |--------------------------------------------------------------------------
    | Save Image
    |--------------------------------------------------------------------------
    */

        $tempDir = storage_path('app/temp');

        if (!file_exists($tempDir)) {
            mkdir($tempDir, 0755, true);
        }

        $tempFile = $tempDir . '/chart_' . uniqid() . '.png';

        imagepng($image, $tempFile, 9);

        imagedestroy($image);

        return $tempFile;
    }
}
